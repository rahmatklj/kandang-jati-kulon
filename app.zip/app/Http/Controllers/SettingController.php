<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Services\ActivityLogger;

class SettingController extends Controller
{
    public function profile()
    {
        $user = auth()->user();
        $recentActivities = \App\Models\ActivityLog::where('user_id', $user->id)
            ->latest()
            ->take(10)
            ->get();

        return view('dashboard.settings.profile', compact('user', 'recentActivities'));
    }

    public function updateProfile(Request $request)
    {
        /** @var \App\Models\User $user */
        $user = auth()->user();

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $user->id,
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'current_password' => 'nullable|required_with:new_password|string',
            'new_password' => 'nullable|string|min:8|confirmed',
        ], [
            'name.required' => 'Nama lengkap wajib diisi.',
            'email.required' => 'Alamat email wajib diisi.',
            'email.unique' => 'Email ini telah digunakan oleh akun lain.',
            'new_password.min' => 'Kata sandi baru minimal 8 karakter.',
            'new_password.confirmed' => 'Konfirmasi kata sandi baru tidak cocok.',
            'current_password.required_with' => 'Kata sandi saat ini wajib diisi jika ingin mengubah kata sandi.',
        ]);

        if ($request->filled('new_password')) {
            if (!\Illuminate\Support\Facades\Hash::check($request->current_password, $user->password)) {
                return back()->withErrors(['current_password' => 'Kata sandi saat ini tidak cocok.'])->withInput();
            }
            $user->password = \Illuminate\Support\Facades\Hash::make($request->new_password);
        }

        if ($request->hasFile('avatar')) {
            if ($user->avatar && !\Illuminate\Support\Str::startsWith($user->avatar, 'http') && Storage::disk('public')->exists($user->avatar)) {
                Storage::disk('public')->delete($user->avatar);
            }
            $path = $request->file('avatar')->store('avatars', 'public');
            $user->avatar = $path;
        } elseif ($request->filled('avatar_url')) {
            $user->avatar = trim($request->avatar_url);
        }

        $user->name = $request->name;
        $user->email = $request->email;
        $user->save();

        ActivityLogger::log('UPDATE', 'Profil Saya', "Memperbarui informasi profil pengguna: {$user->name} ({$user->email})");

        return back()->with('success', 'Profil dan informasi akun Anda berhasil diperbarui.');
    }

    public function visiMisi()
    {
        $settings = Setting::pluck('value', 'key')->toArray();
        return view('dashboard.settings.visi_misi', compact('settings'));
    }

    public function sejarah()
    {
        $settings = Setting::pluck('value', 'key')->toArray();
        return view('dashboard.settings.sejarah', compact('settings'));
    }

    public function aparatur()
    {
        $settings = Setting::pluck('value', 'key')->toArray();
        return view('dashboard.settings.aparatur', compact('settings'));
    }

    public function index()
    {
        $settings = Setting::pluck('value', 'key')->toArray();
        return view('dashboard.settings.index', compact('settings'));
    }

    public function update(Request $request)
    {
        $data = $request->except(['_token', '_method']);
        
        $imageFields = [
            'foto_lurah',
            'kadin_photo',
            'logo_kelurahan',
            'hero_background',
            'foto_sejarah',
            'foto_lpmk',
            'foto_sekretaris',
            'foto_kasi_pemerintahan',
            'foto_kasi_trantib',
            'foto_kasi_kesra',
            'gambar_bagan_struktur',
        ];

        foreach ($imageFields as $field) {
            if ($request->hasFile($field)) {
                $path = $request->file($field)->store('settings', 'public');
                $data[$field] = $path;
            } elseif ($request->filled($field . '_url')) {
                $data[$field] = trim($request->input($field . '_url'));
            } else {
                unset($data[$field]);
            }
            unset($data[$field . '_url']);

            // Sync foto_lurah and kadin_photo for compatibility
            if (isset($data[$field])) {
                if ($field === 'kadin_photo') {
                    $data['foto_lurah'] = $data[$field];
                } elseif ($field === 'foto_lurah') {
                    $data['kadin_photo'] = $data[$field];
                }
            }
        }

        // Sync demografi_total and jumlah_penduduk for compatibility
        if (isset($data['demografi_total'])) {
            $data['jumlah_penduduk'] = $data['demografi_total'];
        } elseif (isset($data['jumlah_penduduk'])) {
            $data['demografi_total'] = $data['jumlah_penduduk'];
        }

        $keysUpdated = array_keys($data);
        foreach ($data as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value]
            );
        }

        ActivityLogger::log('UPDATE', 'Pengaturan', "Mengubah pengaturan web/profil kelurahan (" . count($keysUpdated) . " item)", [
            'updated_keys' => array_slice($keysUpdated, 0, 10)
        ]);

        return back()->with('success', 'Pengaturan struktur aparatur & profil berhasil disimpan.');
    }

    public function destroyKey($key)
    {
        $setting = Setting::where('key', $key)->first();
        if ($setting) {
            $imageKeys = [
                'foto_lurah', 'kadin_photo', 'logo_kelurahan', 'hero_background',
                'foto_sejarah', 'foto_lpmk', 'foto_sekretaris', 'foto_kasi_pemerintahan',
                'foto_kasi_trantib', 'foto_kasi_kesra', 'gambar_bagan_struktur'
            ];

            if (in_array($key, $imageKeys) && $setting->value && !filter_var($setting->value, FILTER_VALIDATE_URL)) {
                Storage::disk('public')->delete($setting->value);
            }
            $setting->delete();

            // Also delete synced key if foto_lurah / kadin_photo
            if ($key === 'kadin_photo') {
                Setting::where('key', 'foto_lurah')->delete();
            } elseif ($key === 'foto_lurah') {
                Setting::where('key', 'kadin_photo')->delete();
            }

            ActivityLogger::log('DELETE', 'Pengaturan', "Menghapus item pengaturan: {$key}");
        }

        return back()->with('success', 'Data ' . str_replace('_', ' ', $key) . ' berhasil dihapus/dikosongkan.');
    }

    public function lapor()
    {
        $settings = Setting::pluck('value', 'key')->toArray();
        $complaints = \App\Models\Complaint::latest()->paginate(10);
        return view('dashboard.integrations.lapor', compact('settings', 'complaints'));
    }

    public function halloSae()
    {
        $settings = Setting::pluck('value', 'key')->toArray();
        return view('dashboard.integrations.hallo_sae', compact('settings'));
    }

    public function contactMaps()
    {
        $settings = Setting::pluck('value', 'key')->toArray();
        return view('dashboard.integrations.contact_maps', compact('settings'));
    }

    public function updateComplaintStatus(Request $request, $id)
    {
        $request->validate(['status' => 'required|in:pending,processing,resolved,rejected']);
        $complaint = \App\Models\Complaint::findOrFail($id);
        $complaint->update(['status' => $request->status]);

        ActivityLogger::log('UPDATE', 'Pengaduan', "Mengubah status pengaduan ID #{$id} menjadi {$request->status}");

        return back()->with('success', 'Status pengaduan berhasil diperbarui.');
    }

    public function destroyComplaint($id)
    {
        $complaint = \App\Models\Complaint::findOrFail($id);
        $title = $complaint->title;
        $complaint->delete();

        ActivityLogger::log('DELETE', 'Pengaduan', "Menghapus pengaduan: {$title}");

        return back()->with('success', 'Data pengaduan berhasil dihapus.');
    }
}
