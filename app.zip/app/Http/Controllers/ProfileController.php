<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function visiMisi()
    {
        $settings = \App\Models\Setting::pluck('value', 'key')->toArray();
        return view('profil.visi-misi', compact('settings'));
    }

    public function struktur()
    {
        $settings = \App\Models\Setting::pluck('value', 'key')->toArray();
        return view('profil.struktur', compact('settings'));
    }

    public function sejarah()
    {
        $settings = \App\Models\Setting::pluck('value', 'key')->toArray();
        return view('profil.sejarah', compact('settings'));
    }

    public function demografi()
    {
        $settings = \App\Models\Setting::pluck('value', 'key')->toArray();
        $rukunWargas = \App\Models\RukunWarga::orderBy('nama_rw')->get();
        return view('profil.demografi', compact('settings', 'rukunWargas'));
    }
}
