<?php

namespace App\Http\Controllers;

use App\Models\Album;
use App\Models\Announcement;
use App\Models\Post;
use App\Models\Service;
use App\Models\Setting;
use App\Models\Maklumat;
use App\Models\Video;
use App\Models\Partnership;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $settingsRaw = Setting::all();
        $settings = $settingsRaw->pluck('value', 'key')->toArray();

        $posts = Post::whereNotNull('published_at')->latest('published_at')->take(4)->get();

        $services = Service::where('is_active', true)->latest()->take(4)->get();

        // Ambil pengumuman (running text) yang aktif
        $announcements = Announcement::where('is_active', true)->latest()->get();

        // Ambil 2 album foto dari dashboard admin
        $galleries = Album::withCount('photos')->latest()->take(2)->get();

        // Ambil 2 video dokumentasi dari dashboard admin
        $videos = Video::latest()->take(2)->get();

        // Ambil maklumat pelayanan yang aktif
        $maklumat = Maklumat::where('is_active', true)->first() ?? Maklumat::first();

        // Ambil data kemitraan aktif
        $partnerships = Partnership::where('is_active', true)->orderBy('sort_order', 'asc')->get();

        return view('home', compact('services', 'posts', 'announcements', 'galleries', 'videos', 'settings', 'maklumat', 'partnerships'));
    }
}
