<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use App\Services\ActivityLogger;

class PostController extends Controller
{
    public function index()
    {
        $posts = Post::with('categoryRelation')->latest()->get();
        return view('dashboard.posts.index', compact('posts'));
    }

    public function create()
    {
        $categories = Category::orderBy('name')->get();
        return view('dashboard.posts.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'author' => 'nullable|string|max:100',
            'excerpt' => 'nullable|string',
            'thumbnail' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'thumbnail_url' => 'nullable|url',
            'content' => 'required',
            'status' => 'required|in:draft,published'
        ]);

        $thumbnailPath = null;
        if ($request->hasFile('thumbnail')) {
            $thumbnailPath = $request->file('thumbnail')->store('posts', 'public');
        } elseif ($request->filled('thumbnail_url')) {
            $thumbnailPath = trim($request->thumbnail_url);
        }

        $categoryName = null;
        if ($request->filled('category_id')) {
            $cat = Category::find($request->category_id);
            $categoryName = $cat?->name;
        }

        $post = Post::create([
            'title' => $request->title,
            'slug' => Str::slug($request->title),
            'category_id' => $request->category_id,
            'category' => $categoryName,
            'author' => $request->author,
            'excerpt' => $request->excerpt,
            'thumbnail' => $thumbnailPath,
            'content' => $request->content,
            'published_at' => $request->status === 'published' ? now() : null,
        ]);

        ActivityLogger::log('CREATE', 'Berita', "Menambahkan berita baru: {$post->title}", [
            'post_id' => $post->id,
            'status' => $request->status
        ]);

        return redirect()->route('dashboard.posts.index')->with('success', 'Berita berhasil ditambahkan.');
    }

    public function edit(Post $post)
    {
        $categories = Category::orderBy('name')->get();
        return view('dashboard.posts.edit', compact('post', 'categories'));
    }

    public function update(Request $request, Post $post)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'author' => 'nullable|string|max:100',
            'excerpt' => 'nullable|string',
            'thumbnail' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'thumbnail_url' => 'nullable|url',
            'content' => 'required',
            'status' => 'required|in:draft,published'
        ]);

        $thumbnailPath = $post->thumbnail;
        if ($request->hasFile('thumbnail')) {
            if ($thumbnailPath && Storage::disk('public')->exists($thumbnailPath)) {
                Storage::disk('public')->delete($thumbnailPath);
            }
            $thumbnailPath = $request->file('thumbnail')->store('posts', 'public');
        } elseif ($request->filled('thumbnail_url')) {
            $thumbnailPath = trim($request->thumbnail_url);
        }

        $categoryName = $post->category;
        if ($request->filled('category_id')) {
            $cat = Category::find($request->category_id);
            $categoryName = $cat?->name;
        } elseif ($request->has('category_id') && is_null($request->category_id)) {
            $categoryName = null;
        }

        $post->update([
            'title' => $request->title,
            'slug' => Str::slug($request->title),
            'category_id' => $request->category_id,
            'category' => $categoryName,
            'author' => $request->author,
            'excerpt' => $request->excerpt,
            'thumbnail' => $thumbnailPath,
            'content' => $request->content,
            'published_at' => $request->status === 'published' ? ($post->published_at ?? now()) : null,
        ]);

        ActivityLogger::log('UPDATE', 'Berita', "Mengubah berita: {$post->title}", [
            'post_id' => $post->id,
            'status' => $request->status
        ]);

        return redirect()->route('dashboard.posts.index')->with('success', 'Berita berhasil diperbarui.');
    }

    public function destroy(Post $post)
    {
        $postTitle = $post->title;
        if ($post->thumbnail && Storage::disk('public')->exists($post->thumbnail)) {
            Storage::disk('public')->delete($post->thumbnail);
        }
        
        $post->delete();

        ActivityLogger::log('DELETE', 'Berita', "Menghapus berita: {$postTitle}");

        return redirect()->route('dashboard.posts.index')->with('success', 'Berita berhasil dihapus.');
    }
}
