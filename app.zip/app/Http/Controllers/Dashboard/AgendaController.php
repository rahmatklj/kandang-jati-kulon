<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Agenda;
use Illuminate\Http\Request;
use App\Services\ActivityLogger;

class AgendaController extends Controller
{
    public function index()
    {
        $agendas = Agenda::orderBy('date', 'desc')->paginate(10);
        return view('dashboard.agendas.index', compact('agendas'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'date' => 'required|date',
            'time' => 'nullable|string',
            'location' => 'required|string|max:255',
            'organizer' => 'required|string|max:255',
        ]);

        $validated['is_active'] = true;
        $agenda = Agenda::create($validated);

        ActivityLogger::log('CREATE', 'Agenda', "Menambahkan agenda baru: {$agenda->title}", [
            'agenda_id' => $agenda->id,
            'date' => $agenda->date
        ]);

        return redirect()->back()->with('success', 'Agenda kegiatan berhasil ditambahkan!');
    }

    public function update(Request $request, $id)
    {
        $agenda = Agenda::findOrFail($id);

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'date' => 'required|date',
            'time' => 'nullable|string',
            'location' => 'required|string|max:255',
            'organizer' => 'required|string|max:255',
        ]);

        $agenda->update($validated);

        ActivityLogger::log('UPDATE', 'Agenda', "Memperbarui agenda: {$agenda->title}", [
            'agenda_id' => $agenda->id,
            'date' => $agenda->date
        ]);

        return redirect()->back()->with('success', 'Agenda kegiatan berhasil diperbarui!');
    }

    public function destroy($id)
    {
        $agenda = Agenda::findOrFail($id);
        $title = $agenda->title;
        $agenda->delete();

        ActivityLogger::log('DELETE', 'Agenda', "Menghapus agenda: {$title}");

        return redirect()->back()->with('success', 'Agenda berhasil dihapus!');
    }
}
