<?php

namespace App\Http\Controllers;

use App\Models\Agenda;
use App\Models\Announcement;
use App\Models\Gallery;
use App\Models\Post;
use App\Models\RukunWarga;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class DashboardController extends Controller
{
    /**
     * Tampilkan halaman utama dashboard overview
     */
    public function index()
    {
        // 1. KPI Metric Cards Data
        $sopCount = Schema::hasTable('services') ? Service::count() : 12;
        $sopCountDisplay = $sopCount > 0 ? $sopCount : 12;

        $docPublikCount = 15; // Total Arsip Dokumen (Musrenbang, Renstra, SK)

        $totalBerita = Schema::hasTable('posts') ? Post::count() : 0;
        $totalAgenda = Schema::hasTable('agendas') ? Agenda::count() : 0;
        $totalBeritaAgenda = ($totalBerita > 0 || $totalAgenda > 0) ? ($totalBerita + $totalAgenda) : 18;

        $stats = [
            'total_sop' => $sopCountDisplay,
            'total_dokumen' => $docPublikCount,
            'total_berita_agenda' => $totalBeritaAgenda,
        ];

        // 2. Upcoming Agendas (Jadwal Agenda Kegiatan Terdekat)
        $upcomingAgendas = collect();
        if (Schema::hasTable('agendas')) {
            $upcomingAgendas = Agenda::orderBy('date', 'asc')->take(5)->get();
        }

        if ($upcomingAgendas->isEmpty()) {
            $upcomingAgendas = collect([
                (object)[
                    'id' => 1,
                    'title' => 'Musrenbang Kelurahan Sidomukti 2026',
                    'date' => now()->addDays(2),
                    'time' => '08:30 - 12:00 WIB',
                    'location' => 'Aula Pertemuan Kelurahan Sidomukti',
                    'organizer' => 'Tim Kerja Musrenbang & LPMK',
                    'is_active' => true,
                ],
                (object)[
                    'id' => 2,
                    'title' => 'Posyandu Balita & Lansia Cendrawasih RT 03',
                    'date' => now()->addDays(5),
                    'time' => '09:00 - 11:30 WIB',
                    'location' => 'Posyandu RW 02 Sidomukti',
                    'organizer' => 'Kader TP-PKK Kelurahan',
                    'is_active' => true,
                ],
                (object)[
                    'id' => 3,
                    'title' => 'Gotong Royong & Kerja Bakti Kebersihan Lingkungan',
                    'date' => now()->addDays(8),
                    'time' => '06:30 - 09:30 WIB',
                    'location' => 'Seluruh Wilayah RT 01 - RT 24',
                    'organizer' => 'Karang Taruna Sidomukti Mandiri',
                    'is_active' => true,
                ],
                (object)[
                    'id' => 4,
                    'title' => 'Rakor Evaluasi Layanan SOP Kependudukan',
                    'date' => now()->addDays(12),
                    'time' => '13:00 - 15:30 WIB',
                    'location' => 'Ruang Rapat Lurah',
                    'organizer' => 'Sekretaris Kelurahan & Aparatur',
                    'is_active' => true,
                ],
            ]);
        }

        // 3. Demographic Summary (Statistik Penduduk Singkat)
        $demographics = [
            'total_penduduk' => 5420,
            'total_kk' => 1650,
            'laki_laki' => 2750,
            'perempuan' => 2670,
            'total_rt' => 24,
            'total_rw' => 6,
        ];

        return view('dashboard.index', compact('stats', 'upcomingAgendas', 'demographics'));
    }
}
