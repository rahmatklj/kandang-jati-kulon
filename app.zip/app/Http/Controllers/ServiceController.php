<?php

namespace App\Http\Controllers;

use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use App\Services\ActivityLogger;

class ServiceController extends Controller
{
    /**
     * Display a listing of SOP / Standar Pelayanan documents in admin.
     */
    public function index()
    {
        $services = Service::orderBy('order', 'asc')->get();
        return view('dashboard.services.index', compact('services'));
    }

    /**
     * Show the form for creating a new SOP document.
     */
    public function create()
    {
        return view('dashboard.services.create');
    }

    /**
     * Store a newly created SOP document in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'requirements' => 'nullable|string',
            'pdf_file' => 'nullable|file|mimes:pdf|max:10240',
            'order' => 'nullable|integer|min:0',
        ], [
            'title.required' => 'Judul SOP / Layanan wajib diisi.',
            'pdf_file.mimes' => 'File dokumen harus berformat PDF.',
            'pdf_file.max' => 'Ukuran file PDF maksimal 10MB.',
        ]);

        $baseSlug = Str::slug($request->title);
        $slug = $baseSlug;
        $count = 1;
        while (Service::where('slug', $slug)->exists()) {
            $slug = $baseSlug . '-' . $count;
            $count++;
        }

        $filePath = null;
        if ($request->hasFile('pdf_file')) {
            $filePath = $request->file('pdf_file')->store('sop_documents', 'public');
        }

        $service = Service::create([
            'title' => $request->title,
            'slug' => $slug,
            'description' => $request->description,
            'requirements' => $request->requirements,
            'file_path' => $filePath,
            'order' => $request->order ?? (Service::max('order') + 1),
            'is_active' => $request->has('is_active') ? true : false,
        ]);

        ActivityLogger::log('CREATE', 'Layanan', "Menambahkan Standar Layanan/SOP baru: {$service->title}", [
            'service_id' => $service->id
        ]);

        return redirect()->route('dashboard.services.index')->with('success', 'Dokumen Standar Pelayanan / SOP berhasil ditambahkan.');
    }

    /**
     * Show the form for editing the specified SOP document.
     */
    public function edit(Service $service)
    {
        return view('dashboard.services.edit', compact('service'));
    }

    /**
     * Update the specified SOP document in storage.
     */
    public function update(Request $request, Service $service)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'requirements' => 'nullable|string',
            'pdf_file' => 'nullable|file|mimes:pdf|max:10240',
            'order' => 'nullable|integer|min:0',
        ], [
            'title.required' => 'Judul SOP / Layanan wajib diisi.',
            'pdf_file.mimes' => 'File dokumen harus berformat PDF.',
            'pdf_file.max' => 'Ukuran file PDF maksimal 10MB.',
        ]);

        $filePath = $service->file_path;
        if ($request->hasFile('pdf_file')) {
            if ($filePath && Storage::disk('public')->exists($filePath)) {
                Storage::disk('public')->delete($filePath);
            }
            $filePath = $request->file('pdf_file')->store('sop_documents', 'public');
        }

        $service->update([
            'title' => $request->title,
            'description' => $request->description,
            'requirements' => $request->requirements,
            'file_path' => $filePath,
            'order' => $request->order ?? $service->order,
            'is_active' => $request->has('is_active') ? true : false,
        ]);

        ActivityLogger::log('UPDATE', 'Layanan', "Mengubah Standar Layanan/SOP: {$service->title}", [
            'service_id' => $service->id
        ]);

        return redirect()->route('dashboard.services.index')->with('success', 'Dokumen Standar Pelayanan / SOP berhasil diperbarui.');
    }

    /**
     * Remove the specified SOP document from storage.
     */
    public function destroy(Service $service)
    {
        $title = $service->title;
        if ($service->file_path && Storage::disk('public')->exists($service->file_path)) {
            Storage::disk('public')->delete($service->file_path);
        }

        $service->delete();

        ActivityLogger::log('DELETE', 'Layanan', "Menghapus Standar Layanan/SOP: {$title}");

        return redirect()->route('dashboard.services.index')->with('success', 'Dokumen Standar Pelayanan / SOP berhasil dihapus.');
    }
}
