<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Dashboard Admin'); ?> - Kelurahan Sidomukti</title>
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="https://upload.wikimedia.org/wikipedia/commons/e/e6/Logo_Kabupaten_Probolinggo_-_Seal_of_Probolinggo_Regency.svg">
    <!-- Tailwind CSS CDN -->
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.0/dist/cdn.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- Cropper.js CSS & JS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.js"></script>
    
    <style>
        body { font-family: 'Inter', sans-serif; }
        [x-cloak] { display: none !important; }

        /* === Rich Text HTML Content (TinyMCE / Markdown) List & Format Styles === */
        .prose ol, .rich-content ol, .content-body ol {
            list-style-type: decimal !important;
            padding-left: 1.75rem !important;
            margin-top: 0.5rem !important;
            margin-bottom: 0.75rem !important;
        }

        .prose ul, .rich-content ul, .content-body ul {
            list-style-type: disc !important;
            padding-left: 1.75rem !important;
            margin-top: 0.5rem !important;
            margin-bottom: 0.75rem !important;
        }

        .prose li, .rich-content li, .content-body li {
            margin-bottom: 0.375rem !important;
            padding-left: 0.25rem !important;
            display: list-item !important;
            list-style-position: outside !important;
        }

        .prose p, .rich-content p, .content-body p {
            margin-bottom: 0.75rem !important;
        }

        /* === Page Entry Animations === */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(18px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up {
            animation: fadeInUp 0.45s ease-out both;
        }

        /* === DataTables — Clean Style === */
        .dataTables_wrapper {
            padding: 0;
        }
        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter {
            margin-bottom: 0.75rem;
        }
        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #e2e8f0;
            border-radius: 0.625rem;
            padding: 0.4rem 0.85rem;
            background-color: #f8fafc;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
            font-size: 0.8125rem;
            color: #334155;
        }
        .dataTables_wrapper .dataTables_filter input:focus {
            border-color: #22c55e;
            box-shadow: 0 0 0 3px rgba(34,197,94,0.12);
            background-color: #ffffff;
        }
        table.dataTable {
            border-collapse: collapse !important;
            margin-top: 0.75rem !important;
            margin-bottom: 0.75rem !important;
            width: 100% !important;
        }
        table.dataTable thead th {
            background-color: #f8fafc;
            color: #94a3b8;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.875rem 1.25rem !important;
            border-bottom: 1px solid #f1f5f9 !important;
            border-top: none !important;
        }
        table.dataTable tbody td {
            padding: 0.875rem 1.25rem !important;
            border-bottom: 1px solid #f8fafc !important;
            color: #334155;
            font-size: 0.875rem;
            vertical-align: middle;
        }
        table.dataTable tbody tr {
            transition: background-color 0.15s;
        }
        table.dataTable tbody tr:hover {
            background-color: #f0fdf4 !important;
        }
        table.dataTable.no-footer {
            border-bottom: 1px solid #f1f5f9 !important;
        }
        /* Info & length text */
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_length { font-size: 0.8125rem; color: #94a3b8; }
        /* Pagination */
        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border-radius: 0.5rem !important;
            border: 1px solid transparent !important;
            background: transparent !important;
            padding: 0.35rem 0.7rem !important;
            margin-left: 0.2rem;
            transition: all 0.15s;
            font-size: 0.8125rem;
            color: #64748b !important;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: #f1f5f9 !important;
            border-color: #e2e8f0 !important;
            color: #1e293b !important;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button.current,
        .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
            background: #22c55e !important;
            color: white !important;
            border-color: #16a34a !important;
            font-weight: 700;
            box-shadow: 0 2px 6px rgba(34,197,94,0.25);
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled,
        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover {
            color: #cbd5e1 !important;
            cursor: default;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased overflow-hidden selection:bg-green-100 selection:text-green-900" x-data="{ sidebarOpen: false }">

    <div class="flex h-screen overflow-hidden">
        
        <!-- Sidebar Component -->
        <?php if (isset($component)) { $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $attributes = $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $component = $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>

        <!-- Main Content Area -->
        <div class="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden bg-slate-50">
            
            <!-- Navbar Component -->
            <?php if (isset($component)) { $__componentOriginal06600c18cadf0581659ec97dd74972b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06600c18cadf0581659ec97dd74972b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06600c18cadf0581659ec97dd74972b4)): ?>
<?php $attributes = $__attributesOriginal06600c18cadf0581659ec97dd74972b4; ?>
<?php unset($__attributesOriginal06600c18cadf0581659ec97dd74972b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06600c18cadf0581659ec97dd74972b4)): ?>
<?php $component = $__componentOriginal06600c18cadf0581659ec97dd74972b4; ?>
<?php unset($__componentOriginal06600c18cadf0581659ec97dd74972b4); ?>
<?php endif; ?>

            <!-- Main Content -->
            <main class="w-full flex-grow p-4 md:p-6 lg:p-8">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            
            <!-- Footer Admin -->
            <footer class="bg-white border-t border-slate-200 py-4 px-6 text-center text-sm text-slate-500 font-medium">
                &copy; <?php echo e(date('Y')); ?> Sistem Informasi Kelurahan Sidomukti. Hak Cipta Dilindungi.
            </footer>
        </div>

    </div>

    <!-- jQuery & DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    
    <script>
        $(document).ready(function() {
            if ($('#dataTable').length) {
                $('#dataTable').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json"
                    },
                    "pageLength": 10,
                    "ordering": true,
                    "info": true
                });
            }
        });
    </script>
    <!-- Modal Universal Image Cropper -->
    <?php if (isset($component)) { $__componentOriginal0ed645126b646352f4628b63dc168b02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ed645126b646352f4628b63dc168b02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image-cropper-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-cropper-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ed645126b646352f4628b63dc168b02)): ?>
<?php $attributes = $__attributesOriginal0ed645126b646352f4628b63dc168b02; ?>
<?php unset($__attributesOriginal0ed645126b646352f4628b63dc168b02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ed645126b646352f4628b63dc168b02)): ?>
<?php $component = $__componentOriginal0ed645126b646352f4628b63dc168b02; ?>
<?php unset($__componentOriginal0ed645126b646352f4628b63dc168b02); ?>
<?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\portal-desa\webkel-sidomukti\resources\views/layouts/admin.blade.php ENDPATH**/ ?>