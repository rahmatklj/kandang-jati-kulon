<?php $__env->startSection('title', isset($user) ? 'Edit Akun Operator' : 'Tambah Akun Operator'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <a href="<?php echo e(route('dashboard.users.index')); ?>" class="text-green-600 hover:text-green-700 font-medium flex items-center gap-2 mb-4">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
        Kembali ke Daftar Akun
    </a>
    <h2 class="text-2xl font-bold text-slate-800"><?php echo e(isset($user) ? 'Edit Akun Operator' : 'Tambah Akun Operator'); ?></h2>
    <p class="text-slate-500 text-sm">Silakan lengkapi formulir di bawah ini untuk menyimpan data akun.</p>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 md:p-8 max-w-3xl">
    <form action="<?php echo e(isset($user) ? route('dashboard.users.update', $user->id) : route('dashboard.users.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($user)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="space-y-6">
            <!-- Nama Lengkap -->
            <div>
                <label class="block text-sm font-bold text-slate-700 mb-2">Nama Lengkap</label>
                <input type="text" name="name" value="<?php echo e(old('name', $user->name ?? '')); ?>" class="w-full px-4 py-3 rounded-lg border <?php echo e($errors->has('name') ? 'border-red-500 focus:ring-red-500' : 'border-slate-300 focus:ring-green-500 focus:border-green-500'); ?> transition shadow-sm" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Email -->
            <div>
                <label class="block text-sm font-bold text-slate-700 mb-2">Email / Username</label>
                <input type="email" name="email" value="<?php echo e(old('email', $user->email ?? '')); ?>" class="w-full px-4 py-3 rounded-lg border <?php echo e($errors->has('email') ? 'border-red-500 focus:ring-red-500' : 'border-slate-300 focus:ring-green-500 focus:border-green-500'); ?> transition shadow-sm" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Role -->
            <div>
                <label class="block text-sm font-bold text-slate-700 mb-2">Role (Peran)</label>
                <select name="role" class="w-full px-4 py-3 rounded-lg border <?php echo e($errors->has('role') ? 'border-red-500 focus:ring-red-500' : 'border-slate-300 focus:ring-green-500 focus:border-green-500'); ?> transition shadow-sm" required>
                    <option value="">-- Pilih Peran --</option>
                    <option value="admin" <?php echo e(old('role', $user->role ?? '') === 'admin' ? 'selected' : ''); ?>>Admin</option>
                    <option value="staf" <?php echo e(old('role', $user->role ?? '') === 'staf' ? 'selected' : ''); ?>>Staf</option>
                </select>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="text-xs text-slate-500 mt-2"><b>Admin:</b> Memiliki hak akses penuh termasuk master data, akun, dan pengaturan sistem. <br><b>Staf:</b> Mengelola berita, artikel, galeri, dll.</p>
            </div>

            <!-- Password -->
            <div>
                <label class="block text-sm font-bold text-slate-700 mb-2">Kata Sandi (Password)</label>
                <input type="password" name="password" class="w-full px-4 py-3 rounded-lg border <?php echo e($errors->has('password') ? 'border-red-500 focus:ring-red-500' : 'border-slate-300 focus:ring-green-500 focus:border-green-500'); ?> transition shadow-sm" <?php echo e(!isset($user) ? 'required' : ''); ?>>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php if(isset($user)): ?>
                <p class="text-xs text-slate-500 mt-2">Kosongkan jika tidak ingin mengubah kata sandi saat ini.</p>
                <?php endif; ?>
            </div>

            <!-- Konfirmasi Password -->
            <div>
                <label class="block text-sm font-bold text-slate-700 mb-2">Konfirmasi Kata Sandi</label>
                <input type="password" name="password_confirmation" class="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-green-500 focus:border-green-500 transition shadow-sm" <?php echo e(!isset($user) ? 'required' : ''); ?>>
            </div>
        </div>

        <div class="mt-8 pt-6 border-t border-slate-200 flex justify-end">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-lg shadow-md transition flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                Simpan Akun
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\portal-desa\webkel-sidomukti\resources\views/dashboard/users/form.blade.php ENDPATH**/ ?>