<?php $__env->startSection('title', 'Kelola Standar Layanan & SOP'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
    <div>
        <h2 class="text-2xl font-bold text-slate-800">Kelola Standar Layanan & SOP</h2>
        <p class="text-slate-500 text-sm">Kelola repositori dokumen SOP, standar pelayanan publik, dan berkas PDF kelurahan.</p>
    </div>
    <a href="<?php echo e(route('dashboard.services.create')); ?>" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-5 rounded-xl shadow-md shadow-emerald-600/20 hover:-translate-y-0.5 transition-all duration-300 flex items-center gap-2 text-sm">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
        Tambah Dokumen SOP
    </a>
</div>

<?php if(session('success')): ?>
<div class="bg-emerald-100 border border-emerald-400 text-emerald-800 px-4 py-3 rounded-xl relative mb-6 shadow-sm flex items-center justify-between" role="alert">
    <div class="flex items-center gap-2">
        <svg class="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
    </div>
    <button type="button" onclick="this.parentElement.remove()" class="text-emerald-800 font-bold">&times;</button>
</div>
<?php endif; ?>

<div class="bg-white rounded-2xl shadow-lg shadow-slate-200/50 border border-slate-100 overflow-hidden p-2 sm:p-4">
    <div class="overflow-x-auto">
        <table id="dataTable" class="w-full text-left text-sm text-slate-600">
            <thead class="bg-slate-50 text-slate-700 uppercase font-semibold border-b border-slate-200">
                <tr>
                    <th scope="col" class="px-6 py-4">No & Judul Dokumen SOP</th>
                    <th scope="col" class="px-6 py-4">Slug URL</th>
                    <th scope="col" class="px-6 py-4 text-center">Berkas PDF</th>
                    <th scope="col" class="px-6 py-4 text-center">Status</th>
                    <th scope="col" class="px-6 py-4 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-slate-50/70 transition">
                    <td class="px-6 py-4">
                        <div class="flex items-start gap-3">
                            <span class="w-7 h-7 rounded-lg bg-emerald-100/80 text-emerald-700 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                                <?php echo e($service->order ?? $loop->iteration); ?>

                            </span>
                            <div>
                                <a href="<?php echo e(route('services.show', $service->slug)); ?>" target="_blank" class="font-bold text-slate-900 hover:text-emerald-700 transition">
                                    <?php echo e($service->title); ?>

                                </a>
                                <p class="text-xs text-slate-400 mt-0.5 line-clamp-1 max-w-sm"><?php echo e($service->description ?: 'Tidak ada keterangan tambahan.'); ?></p>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4">
                        <code class="px-2 py-1 bg-slate-100 text-slate-700 rounded-md text-[11px] font-mono border border-slate-200 max-w-xs truncate inline-block"><?php echo e($service->slug); ?></code>
                    </td>
                    <td class="px-6 py-4 text-center">
                        <?php if($service->file_path && Storage::disk('public')->exists($service->file_path)): ?>
                            <a href="<?php echo e(Storage::url($service->file_path)); ?>" target="_blank" class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                                Lihat PDF
                            </a>
                        <?php else: ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                                Belum Diunggah
                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-center">
                        <?php if($service->is_active): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-green-100 text-green-800">
                                Aktif
                            </span>
                        <?php else: ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800">
                                Nonaktif
                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="<?php echo e(route('services.show', $service->slug)); ?>" target="_blank" class="text-emerald-600 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 p-2 rounded-lg transition" title="Lihat Tampilan Publik">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                            </a>
                            <a href="<?php echo e(route('dashboard.services.edit', $service->id)); ?>" class="text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 p-2 rounded-lg transition" title="Edit & Unggah PDF">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                            </a>
                            <form action="<?php echo e(route('dashboard.services.destroy', $service->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus dokumen SOP ini?');" class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 p-2 rounded-lg transition" title="Hapus Dokumen">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\portal-desa\webkel-sidomukti\resources\views/dashboard/services/index.blade.php ENDPATH**/ ?>