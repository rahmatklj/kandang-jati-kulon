<?php $__env->startSection('title', 'Kelola Informasi Kontak & Google Maps'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
    <div>
        <h2 class="text-2xl font-bold text-slate-800">Kelola Informasi Kontak & Google Maps</h2>
        <p class="text-slate-500 text-sm">Kelola informasi alamat fisik kantor kelurahan, telepon resmi, email, serta sematan peta navigasi lokasi Google Maps.</p>
    </div>
    <div>
        <a href="<?php echo e(route('contact')); ?>" target="_blank" class="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl shadow-sm transition">
            <svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
            Lihat Halaman Kontak Publik
        </a>
    </div>
</div>

<?php if(session('success')): ?>
<div class="bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 p-4 rounded-xl mb-6 shadow-sm flex items-center justify-between" role="alert">
    <div class="flex items-center gap-3">
        <svg class="w-5 h-5 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
    </div>
    <button onclick="this.parentElement.remove()" class="text-emerald-500 hover:text-emerald-700 font-bold">&times;</button>
</div>
<?php endif; ?>

<form action="<?php echo e(route('dashboard.settings.update')); ?>" method="POST" class="space-y-6">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left Column: Form Input Kontak -->
        <div class="lg:col-span-7 space-y-6">
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                        </div>
                        <div>
                            <h3 class="font-bold text-slate-800 text-base">Informasi Kontak & Jam Operasional</h3>
                            <p class="text-slate-500 text-xs">Telepon kantor, email resmi, alamat, dan jam pelayanan publik.</p>
                        </div>
                    </div>
                </div>

                <div class="p-6 md:p-8 space-y-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Telepon Kantor Resmi</label>
                            <input type="text" name="telepon" value="<?php echo e($settings['telepon'] ?? '(0335) 123456'); ?>" required class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-medium text-slate-800" placeholder="Contoh: (0335) 123456">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Email Resmi Kelurahan</label>
                            <input type="email" name="email" value="<?php echo e($settings['email'] ?? 'info@sidomukti.desa.id'); ?>" required class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-medium text-slate-800" placeholder="Contoh: info@sidomukti.desa.id">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Alamat Lengkap Fisik Kantor</label>
                        <textarea name="alamat" rows="2" required class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-medium text-slate-800"><?php echo e($settings['alamat'] ?? 'Jl. Raya Sidomukti No. 10, Kelurahan Sidomukti, Kecamatan Kraksaan, Kabupaten Probolinggo, Jawa Timur 67282'); ?></textarea>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Jam Kerja Pelayanan (Senin - Kamis)</label>
                            <input type="text" name="jam_layanan_senin_kamis" value="<?php echo e($settings['jam_layanan_senin_kamis'] ?? '07.30 - 15.00 WIB'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-medium text-slate-800" placeholder="07.30 - 15.00 WIB">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Jam Kerja Pelayanan (Jumat)</label>
                            <input type="text" name="jam_layanan_jumat" value="<?php echo e($settings['jam_layanan_jumat'] ?? '07.30 - 11.30 WIB'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-medium text-slate-800" placeholder="07.30 - 11.30 WIB">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Google Maps Embed Section -->
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                        </div>
                        <div>
                            <h3 class="font-bold text-slate-800 text-base">Pengaturan Sematan Peta Google Maps</h3>
                            <p class="text-slate-500 text-xs">Kode sematan iFrame atau link tautan Peta Google Maps Kantor Kelurahan.</p>
                        </div>
                    </div>
                </div>

                <div class="p-6 md:p-8 space-y-5">
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Tautan Navigasi Langsung Google Maps</label>
                        <input type="url" name="gmaps_link" value="<?php echo e($settings['gmaps_link'] ?? 'https://maps.google.com/?q=Kelurahan+Sidomukti+Kraksaan'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-mono" placeholder="https://maps.google.com/?q=...">
                    </div>

                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Kode Sematan iFrame Google Maps (SRC Embed URL)</label>
                        <textarea name="gmaps_iframe" rows="3" class="w-full px-4 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-mono"><?php echo e($settings['gmaps_iframe'] ?? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15814.159392817812!2d113.407!3d-7.755!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd701a5d24d2ab7%3A0x7d0186c478a87ab5!2sSidomukti%2C%20Kraksaan%2C%20Probolinggo%20Regency%2C%20East%20Java!5e0!3m2!1sen!2sid!4v1700000000000!5m2!1sen!2sid'); ?></textarea>
                        <p class="text-[11px] text-slate-400 mt-1">Tempelkan URL dari atribut `src="..."` kode embed Google Maps.</p>
                    </div>

                    <div class="flex justify-end pt-2">
                        <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition">Simpan Informasi Kontak & Maps</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column: Interactive Map & Contact Card Preview -->
        <div class="lg:col-span-5 space-y-6">
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
                <h4 class="font-bold text-slate-800 text-sm flex items-center gap-2">
                    <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path></svg>
                    Pratinjau Peta Google Maps Kantor
                </h4>

                <div class="w-full h-64 rounded-xl overflow-hidden border border-slate-200 shadow-xs bg-slate-100">
                    <iframe src="<?php echo e($settings['gmaps_iframe'] ?? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15814.159392817812!2d113.407!3d-7.755!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd701a5d24d2ab7%3A0x7d0186c478a87ab5!2sSidomukti%2C%20Kraksaan%2C%20Probolinggo%20Regency%2C%20East%20Java!5e0!3m2!1sen!2sid!4v1700000000000!5m2!1sen!2sid'); ?>" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>

                <div class="bg-slate-50 rounded-xl p-4 border border-slate-200 text-xs space-y-2 text-slate-700">
                    <div class="font-bold text-slate-900 border-b border-slate-200 pb-2">Informasi Publik Halaman Kontak</div>
                    <div><strong class="text-slate-900">Alamat:</strong> <?php echo e($settings['alamat'] ?? 'Jl. Raya Sidomukti No. 10'); ?></div>
                    <div><strong class="text-slate-900">Telepon:</strong> <?php echo e($settings['telepon'] ?? '(0335) 123456'); ?></div>
                    <div><strong class="text-slate-900">Email:</strong> <?php echo e($settings['email'] ?? 'info@sidomukti.desa.id'); ?></div>
                </div>
            </div>
        </div>

    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\portal-desa\webkel-sidomukti\resources\views/dashboard/integrations/contact_maps.blade.php ENDPATH**/ ?>