<?php $__env->startSection('title', 'Tambah Video Dokumentasi Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 flex justify-between items-center">
    <div>
        <h2 class="text-2xl font-bold text-slate-800">Tambah Video Dokumentasi</h2>
        <p class="text-slate-500 text-sm">Tambahkan tayangan video baru dari YouTube ke halaman dokumentasi publik.</p>
    </div>
    <a href="<?php echo e(route('dashboard.videos.index')); ?>" class="text-slate-500 hover:text-slate-700 font-medium py-2 px-4 border border-slate-300 rounded-lg shadow-sm bg-white hover:bg-slate-50 transition flex items-center gap-2">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
        Batal
    </a>
</div>

<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden max-w-2xl">
    <form action="<?php echo e(route('dashboard.videos.store')); ?>" method="POST" class="p-6 md:p-8 space-y-6">
        <?php echo csrf_field(); ?>

        <div>
            <label for="title" class="block text-sm font-bold text-slate-700 mb-2">Judul Video Dokumentasi <span class="text-red-500">*</span></label>
            <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>" required autofocus class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-2 focus:ring-green-500 transition shadow-sm" placeholder="Contoh: Liputan Jalan Sehat & Semarak HUT RI 2026">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label for="category" class="block text-sm font-bold text-slate-700 mb-2">Kategori Kegiatan <span class="text-red-500">*</span></label>
                <select name="category" id="category" required class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-green-500 transition bg-white shadow-sm">
                    <option value="pemerintahan" <?php echo e(old('category') == 'pemerintahan' ? 'selected' : ''); ?>>Pemerintahan & Pelayanan</option>
                    <option value="pembangunan" <?php echo e(old('category') == 'pembangunan' ? 'selected' : ''); ?>>Infrastruktur & Pembangunan</option>
                    <option value="pemberdayaan" <?php echo e(old('category') == 'pemberdayaan' ? 'selected' : ''); ?>>Pemberdayaan & UMKM</option>
                    <option value="keagamaan" <?php echo e(old('category') == 'keagamaan' ? 'selected' : ''); ?>>Keagamaan & Kemasyarakatan</option>
                    <option value="hut-ri" <?php echo e(old('category') == 'hut-ri' ? 'selected' : ''); ?>>Peringatan HUT RI & Seni Budaya</option>
                </select>
            </div>

            <div>
                <label for="duration" class="block text-sm font-bold text-slate-700 mb-2">Durasi Video (Opsional)</label>
                <input type="text" name="duration" id="duration" value="<?php echo e(old('duration')); ?>" class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-green-500 transition shadow-sm" placeholder="Contoh: 04:15">
            </div>
        </div>

        <div>
            <label for="youtube_url" class="block text-sm font-bold text-slate-700 mb-2">Link / URL Video YouTube <span class="text-red-500">*</span></label>
            <input type="url" name="youtube_url" id="youtube_url" value="<?php echo e(old('youtube_url')); ?>" required class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['youtube_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-2 focus:ring-green-500 transition shadow-sm font-mono text-xs" placeholder="https://www.youtube.com/watch?v=dQw4w9WgXcQ atau https://youtu.be/...">
            <?php $__errorArgs = ['youtube_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <p class="text-xs text-slate-500 mt-1.5">Sistem akan secara otomatis mengambil thumbnail gambar dan mengaktifkan pemutar video YouTube.</p>
        </div>

        <div>
            <label for="description" class="block text-sm font-bold text-slate-700 mb-2">Deskripsi Singkat Video</label>
            <textarea name="description" id="description" rows="3" class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-green-500 transition shadow-sm" placeholder="Tuliskan ringkasan isi video dokumentasi ini..."></textarea>
        </div>

        <div class="mt-8 pt-5 border-t border-slate-200 flex justify-end">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-xl shadow-md transition flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                Simpan Video
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\portal-desa\webkel-sidomukti\resources\views/dashboard/videos/create.blade.php ENDPATH**/ ?>