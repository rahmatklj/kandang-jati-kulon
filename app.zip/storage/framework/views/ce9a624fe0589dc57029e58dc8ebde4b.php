<?php $__env->startSection('title', 'Kelola Identitas & Pengaturan Umum'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
    <div>
        <h2 class="text-2xl font-bold text-slate-800">Kelola Identitas & Pengaturan Umum</h2>
        <p class="text-slate-500 text-sm">Kelola informasi publik, hero banner, statistik, sambutan pimpinan, dan kontak resmi kelurahan.</p>
    </div>
    <div>
        <a href="<?php echo e(route('home')); ?>" target="_blank" class="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl shadow-sm transition">
            <svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
            Lihat Beranda Publik
        </a>
    </div>
</div>

<?php if(session('success')): ?>
<div class="bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 p-4 rounded-xl mb-6 shadow-sm flex items-center justify-between" role="alert">
    <div class="flex items-center gap-3">
        <svg class="w-5 h-5 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <span class="font-medium text-sm"><?php echo e(session('success')); ?></span>
    </div>
    <button onclick="this.parentElement.remove()" class="text-emerald-500 hover:text-emerald-700 font-bold">&times;</button>
</div>
<?php endif; ?>

<form action="<?php echo e(route('dashboard.settings.update')); ?>" method="POST" enctype="multipart/form-data" class="space-y-8">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <!-- Section 1: Logo & Branding Kelurahan -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5m3 0h1m-1-4h.01M9 16h.01M9 12h.01M9 8h.01M15 16h.01M15 12h.01M15 8h.01"></path></svg>
                </div>
                <div>
                    <h3 class="font-bold text-slate-800 text-base">Identitas & Logo Kelurahan</h3>
                    <p class="text-slate-500 text-xs">Identitas utama yang tampil pada Navbar dan Header Website.</p>
                </div>
            </div>
        </div>
        <div class="p-6 md:p-8 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Nama Instansi Kelurahan</label>
                    <input type="text" name="agency_name" value="<?php echo e($settings['agency_name'] ?? 'KELURAHAN SIDOMUKTI'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-semibold text-slate-800" placeholder="Contoh: KELURAHAN SIDOMUKTI">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Kecamatan & Kabupaten</label>
                    <input type="text" name="regency_name" value="<?php echo e($settings['regency_name'] ?? 'Kecamatan Kraksaan, Kabupaten Probolinggo'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800" placeholder="Contoh: Kecamatan Kraksaan, Kabupaten Probolinggo">
                </div>
            </div>

            <div class="pt-4 border-t border-slate-100">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Logo Kelurahan (Muncul di Header Navigation)</label>
                <div class="flex flex-col sm:flex-row items-start sm:items-center gap-5">
                    <div class="w-20 h-20 rounded-2xl border border-slate-200 bg-slate-50 p-2 flex items-center justify-center shrink-0 shadow-xs relative">
                        <?php
                            $logoVal = $settings['logo_kelurahan'] ?? '';
                            $logoSrc = $logoVal ? (\Illuminate\Support\Str::startsWith($logoVal, ['http://', 'https://']) ? $logoVal : Storage::url($logoVal)) : asset('images/logo-prob.png');
                        ?>
                        <img id="previewLogoKelurahan" src="<?php echo e($logoSrc); ?>" alt="Logo Saat Ini" class="max-w-full max-h-full object-contain">
                    </div>
                    <div class="flex-grow space-y-3">
                        <div>
                            <span class="text-xs font-semibold text-slate-600 mb-1 block">Opsi A: Unggah Berkas File Logo</span>
                            <div class="flex items-center gap-2">
                                <input type="file" name="logo_kelurahan" id="logo_kelurahan" data-ratio="1:1" data-preview="#previewLogoKelurahan" accept="image/png, image/svg+xml, image/jpeg" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 transition cursor-pointer">
                                <button type="button" onclick="window.CropHelper && window.CropHelper.open(document.getElementById('logo_kelurahan'))" class="shrink-0 text-xs text-emerald-700 bg-emerald-50 hover:bg-emerald-100 font-semibold px-3 py-2 rounded-xl border border-emerald-200 transition inline-flex items-center gap-1.5 shadow-sm">
                                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 0L4 4m5.121 5.121L4 14.121M14.121 9.121L19 4"/></svg>
                                    Potong
                                </button>
                            </div>
                        </div>
                        <div>
                            <span class="text-xs font-semibold text-slate-600 mb-1 block">Opsi B: Atau Tempel Link/URL Foto Logo (HTTP/HTTPS)</span>
                            <input type="url" name="logo_kelurahan_url" value="<?php echo e(\Illuminate\Support\Str::startsWith($logoVal, ['http://', 'https://']) ? $logoVal : ''); ?>" oninput="if(this.value){ document.getElementById('previewLogoKelurahan').src = this.value; }" class="w-full px-4 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-mono" placeholder="https://domain.com/logo.png">
                        </div>
                        <?php if(isset($settings['logo_kelurahan']) && $settings['logo_kelurahan']): ?>
                        <div class="pt-1">
                            <button type="submit" form="destroy-logo-form" onclick="return confirm('Yakin ingin menghapus logo dan menggunakan logo bawaan?')" class="text-xs text-red-600 hover:text-red-800 font-bold underline flex items-center gap-1">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                Reset Logo ke Default
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Section 2: Hero Banner Beranda -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                </div>
                <div>
                    <h3 class="font-bold text-slate-800 text-base">Hero Banner Utama (Top Header Beranda)</h3>
                    <p class="text-slate-500 text-xs">Pengaturan judul utama, slogan, dan gambar latar belakang banner beranda.</p>
                </div>
            </div>
        </div>
        <div class="p-6 md:p-8 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Judul Utama - Baris 1 (Teks Putih)</label>
                    <input type="text" name="hero_title_1" value="<?php echo e($settings['hero_title_1'] ?? 'Pelayanan Publik'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-bold text-slate-800">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Judul Utama - Baris 2 (Teks Hijau Highlight)</label>
                    <input type="text" name="hero_title_2" value="<?php echo e($settings['hero_title_2'] ?? 'Berbasis Digital Cepat & Transparan'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-bold text-emerald-700">
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Deskripsi Singkat / Sub-Judul Hero Banner</label>
                <textarea name="hero_subtitle" rows="2" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-700"><?php echo e($settings['hero_subtitle'] ?? 'Kini administrasi kependudukan lebih cepat dan transparan melalui integrasi digital.'); ?></textarea>
            </div>

            <div class="pt-4 border-t border-slate-100">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Gambar Background Hero Banner</label>
                <div class="flex flex-col md:flex-row items-start md:items-center gap-5">
                    <div class="w-full md:w-64 h-32 rounded-2xl border border-slate-200 bg-slate-900 overflow-hidden shrink-0 shadow-xs relative">
                        <?php
                            $heroBgVal = $settings['hero_background'] ?? '';
                            $heroBgSrc = $heroBgVal ? (\Illuminate\Support\Str::startsWith($heroBgVal, ['http://', 'https://']) ? $heroBgVal : Storage::url($heroBgVal)) : asset('hero-bg.jpg');
                        ?>
                        <img id="previewHeroBg" src="<?php echo e($heroBgSrc); ?>" alt="Background Banner Saat Ini" class="w-full h-full object-cover opacity-80">
                        <div class="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/40 to-transparent flex items-end p-3">
                            <span class="text-[10px] text-emerald-400 font-bold bg-slate-900/90 px-2 py-0.5 rounded border border-slate-700">Preview Layout</span>
                        </div>
                    </div>
                    <div class="flex-grow space-y-3">
                        <div>
                            <span class="text-xs font-semibold text-slate-600 mb-1 block">Opsi A: Unggah Berkas File Latar Belakang (Otomatis Pas & HD 16:9)</span>
                            <div class="flex items-center gap-2">
                                <input type="file" name="hero_background" id="hero_background" data-ratio="16:9" data-preview="#previewHeroBg" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 transition cursor-pointer">
                                <button type="button" onclick="window.CropHelper && window.CropHelper.open(document.getElementById('hero_background'))" class="shrink-0 text-xs text-blue-700 bg-blue-50 hover:bg-blue-100 font-semibold px-3 py-2 rounded-xl border border-blue-200 transition inline-flex items-center gap-1.5 shadow-sm">
                                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 0L4 4m5.121 5.121L4 14.121M14.121 9.121L19 4"/></svg>
                                    Potong HD
                                </button>
                            </div>
                        </div>
                        <div>
                            <span class="text-xs font-semibold text-slate-600 mb-1 block">Opsi B: Atau Tempel Link/URL Latar Belakang (HTTP/HTTPS)</span>
                            <input type="url" name="hero_background_url" value="<?php echo e(\Illuminate\Support\Str::startsWith($heroBgVal, ['http://', 'https://']) ? $heroBgVal : ''); ?>" oninput="if(this.value){ document.getElementById('previewHeroBg').src = this.value; }" class="w-full px-4 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-mono" placeholder="https://images.unsplash.com/photo-example.jpg">
                        </div>
                        <?php if(isset($settings['hero_background']) && $settings['hero_background']): ?>
                        <div class="pt-1">
                            <button type="submit" form="destroy-hero-bg-form" onclick="return confirm('Yakin ingin menghapus gambar latar belakang dan memakai default?')" class="text-xs text-red-600 hover:text-red-800 font-bold underline flex items-center gap-1">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                Reset Background ke Default
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Section 3: Sambutan Lurah / Pimpinan -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                </div>
                <div>
                    <h3 class="font-bold text-slate-800 text-base">Sambutan Lurah & Pimpinan Kelurahan</h3>
                    <p class="text-slate-500 text-xs">Profil singkat pimpinan yang tampil pada Seksi Sambutan Beranda Utama.</p>
                </div>
            </div>
        </div>
        <div class="p-6 md:p-8 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Nama Lengkap Lurah / Pimpinan</label>
                    <input type="text" name="kadin_name" value="<?php echo e($settings['kadin_name'] ?? $settings['lurah_name'] ?? 'H. Ahmad Syarif, S.STP, M.Si'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-bold text-slate-800">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Jabatan Resmi</label>
                    <input type="text" name="kadin_title" value="<?php echo e($settings['kadin_title'] ?? $settings['lurah_title'] ?? 'LURAH SIDOMUKTI'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-bold text-emerald-700">
                </div>
            </div>

            <div class="pt-4 border-t border-slate-100">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Foto Resmi Lurah / Pimpinan</label>
                <div class="flex flex-col sm:flex-row items-start sm:items-center gap-5">
                    <div class="w-24 h-32 rounded-2xl border-2 border-slate-200 bg-slate-100 overflow-hidden shrink-0 shadow-xs">
                        <?php
                            $kadinVal = $settings['kadin_photo'] ?? $settings['foto_lurah'] ?? '';
                            $kadinSrc = $kadinVal ? (\Illuminate\Support\Str::startsWith($kadinVal, ['http://', 'https://']) ? $kadinVal : Storage::url($kadinVal)) : 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=600&auto=format&fit=crop';
                        ?>
                        <img id="previewKadinPhoto" src="<?php echo e($kadinSrc); ?>" alt="Foto Lurah Saat Ini" class="w-full h-full object-cover">
                    </div>
                    <div class="flex-grow space-y-3">
                        <div>
                            <span class="text-xs font-semibold text-slate-600 mb-1 block">Opsi A: Unggah Berkas Foto Pimpinan</span>
                            <div class="flex items-center gap-2">
                                <input type="file" name="kadin_photo" id="kadin_photo" data-ratio="1:1" data-preview="#previewKadinPhoto" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 transition cursor-pointer">
                                <button type="button" onclick="window.CropHelper && window.CropHelper.open(document.getElementById('kadin_photo'))" class="shrink-0 text-xs text-purple-700 bg-purple-50 hover:bg-purple-100 font-semibold px-3 py-2 rounded-xl border border-purple-200 transition inline-flex items-center gap-1.5 shadow-sm">
                                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 0L4 4m5.121 5.121L4 14.121M14.121 9.121L19 4"/></svg>
                                    Potong
                                </button>
                            </div>
                        </div>
                        <div>
                            <span class="text-xs font-semibold text-slate-600 mb-1 block">Opsi B: Atau Tempel Link/URL Foto Pimpinan (HTTP/HTTPS)</span>
                            <input type="url" name="kadin_photo_url" value="<?php echo e(\Illuminate\Support\Str::startsWith($kadinVal, ['http://', 'https://']) ? $kadinVal : ''); ?>" oninput="if(this.value){ document.getElementById('previewKadinPhoto').src = this.value; }" class="w-full px-4 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 transition font-mono" placeholder="https://images.unsplash.com/photo-lurah.jpg">
                        </div>
                        <?php if(isset($settings['kadin_photo']) && $settings['kadin_photo']): ?>
                        <div class="pt-1">
                            <button type="submit" form="destroy-kadin-photo-form" onclick="return confirm('Yakin ingin menghapus foto pimpinan dan memakai foto bawaan?')" class="text-xs text-red-600 hover:text-red-800 font-bold underline flex items-center gap-1">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                Reset Foto Pimpinan ke Default
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Section 4: Statistik Beranda (Floating Bar) -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                </div>
                <div>
                    <h3 class="font-bold text-slate-800 text-base">Statistik Ringkas Beranda (Floating Stat Bar)</h3>
                    <p class="text-slate-500 text-xs">Angka statistik pencapaian & data kependudukan yang tampil melayang di bawah banner.</p>
                </div>
            </div>
        </div>
        <div class="p-6 md:p-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Jumlah Penduduk (Warga)</label>
                    <div class="relative">
                        <input type="number" name="jumlah_penduduk" value="<?php echo e($settings['jumlah_penduduk'] ?? '8542'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-bold text-slate-800">
                        <span class="absolute right-4 top-2.5 text-xs text-slate-400 font-semibold">Jiwa</span>
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Permohonan Surat Selesai</label>
                    <div class="relative">
                        <input type="number" name="permohonan_selesai" value="<?php echo e($settings['permohonan_selesai'] ?? '1247'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-bold text-slate-800">
                        <span class="absolute right-4 top-2.5 text-xs text-slate-400 font-semibold">Berkas</span>
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Tingkat Kepuasan Warga (%)</label>
                    <div class="relative">
                        <input type="number" name="tingkat_kepuasan" value="<?php echo e($settings['tingkat_kepuasan'] ?? '98'); ?>" min="0" max="100" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-bold text-emerald-700">
                        <span class="absolute right-4 top-2.5 text-xs text-emerald-600 font-extrabold">%</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Section 5: Kontak, Hotline & Alamat -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                </div>
                <div>
                    <h3 class="font-bold text-slate-800 text-base">Kontak Resmi, Hotline WhatsApp & Footer</h3>
                    <p class="text-slate-500 text-xs">Nomor telepon kantor, WhatsApp pelayanan, email resmi, dan alamat fisik kantor.</p>
                </div>
            </div>
        </div>
        <div class="p-6 md:p-8 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Telepon Kantor</label>
                    <input type="text" name="telepon" value="<?php echo e($settings['telepon'] ?? '(0335) 123456'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800" placeholder="Contoh: (0335) 123456">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">WhatsApp Hotline (Format 62...)</label>
                    <input type="text" name="wa_number" value="<?php echo e($settings['wa_number'] ?? '6282131001001'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-semibold text-slate-800" placeholder="Contoh: 6282131001001">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Email Resmi Kelurahan</label>
                    <input type="email" name="email" value="<?php echo e($settings['email'] ?? 'info@sidomukti.desa.id'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800" placeholder="Contoh: info@sidomukti.desa.id">
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Alamat Lengkap Kantor Kelurahan</label>
                <textarea name="alamat" rows="2" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800"><?php echo e($settings['alamat'] ?? 'Jl. Raya Sidomukti No. 10, Kelurahan Sidomukti, Kecamatan Kraksaan, Kabupaten Probolinggo, Jawa Timur 67282'); ?></textarea>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Tautan Portal SP4N LAPOR!</label>
                <input type="url" name="lapor_link" value="<?php echo e($settings['lapor_link'] ?? 'https://www.lapor.go.id/'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800" placeholder="https://www.lapor.go.id/">
            </div>
        </div>
    </div>

    <!-- Section 6: Media Sosial -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                </div>
                <div>
                    <h3 class="font-bold text-slate-800 text-base">Tautan Media Sosial Footer</h3>
                    <p class="text-slate-500 text-xs">Link jejaring media sosial kelurahan yang tampil pada footer halaman publik.</p>
                </div>
            </div>
        </div>
        <div class="p-6 md:p-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Instagram URL</label>
                    <input type="url" name="instagram" value="<?php echo e($settings['instagram'] ?? '#'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800" placeholder="https://instagram.com/kelurahansidomukti">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">YouTube Channel URL</label>
                    <input type="url" name="youtube" value="<?php echo e($settings['youtube'] ?? '#'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800" placeholder="https://youtube.com/@kelurahansidomukti">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">TikTok Account URL</label>
                    <input type="url" name="tiktok" value="<?php echo e($settings['tiktok'] ?? '#'); ?>" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800" placeholder="https://tiktok.com/@kelurahansidomukti">
                </div>
            </div>
        </div>
    </div>

    <!-- Sticky Bottom Submit Bar -->
    <div class="sticky bottom-4 z-40 bg-slate-900/90 backdrop-blur-md text-white p-4 rounded-2xl shadow-2xl border border-slate-700 flex items-center justify-between">
        <div class="hidden sm:flex items-center gap-3">
            <div class="w-3 h-3 rounded-full bg-emerald-400 animate-pulse"></div>
            <span class="text-xs text-slate-300 font-medium">Perubahan akan langsung memperbarui Beranda & Footer Website Publik.</span>
        </div>
        <button type="submit" class="w-full sm:w-auto px-8 py-3 bg-gradient-to-r from-emerald-500 to-emerald-700 hover:from-emerald-600 hover:to-emerald-800 text-white font-extrabold text-sm rounded-xl shadow-lg shadow-emerald-900/30 transition flex items-center justify-center gap-2 cursor-pointer">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            Simpan Perubahan Pengaturan
        </button>
    </div>
</form>


<?php if(isset($settings['logo_kelurahan']) && $settings['logo_kelurahan']): ?>
<form id="destroy-logo-form" action="<?php echo e(route('dashboard.settings.destroy', 'logo_kelurahan')); ?>" method="POST" class="hidden">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<?php endif; ?>

<?php if(isset($settings['hero_background']) && $settings['hero_background']): ?>
<form id="destroy-hero-bg-form" action="<?php echo e(route('dashboard.settings.destroy', 'hero_background')); ?>" method="POST" class="hidden">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<?php endif; ?>

<?php if(isset($settings['kadin_photo']) && $settings['kadin_photo']): ?>
<form id="destroy-kadin-photo-form" action="<?php echo e(route('dashboard.settings.destroy', 'kadin_photo')); ?>" method="POST" class="hidden">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\portal-desa\webkel-sidomukti\resources\views/dashboard/settings/index.blade.php ENDPATH**/ ?>