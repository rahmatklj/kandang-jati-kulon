<?php $__env->startSection('title', 'Kelola Kemitraan Strategis'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="{ 
    createModal: false, 
    editModal: false, 
    deleteModal: false,
    deleteFormAction: '',
    deletePartnerName: '',
    editPartner: { id: '', name: '', category: 'Instansi Pemerintah', logo_url: '', description: '', website: '', contact_person: '', phone: '', is_active: true, sort_order: 0 },
    openEdit(partner) {
        this.editPartner = { ...partner, logo_url: partner.logo };
        this.editModal = true;
    },
    openDelete(id, name) {
        this.deleteFormAction = '<?php echo e(url('/dashboard/partnerships')); ?>/' + id;
        this.deletePartnerName = name;
        this.deleteModal = true;
    }
}">

    <!-- Top Title & Header -->
    <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
            <h1 class="text-2xl font-extrabold text-slate-800 tracking-tight">Kelola Kemitraan Strategis</h1>
            <p class="text-sm text-slate-500 mt-1">Manajemen mitra kerja instansi pemerintah, BUMN, lembaga pendidikan, dan sektor swasta Kelurahan Sidomukti.</p>
        </div>

        <button @click="createModal = true" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase px-4 py-2.5 rounded-xl shadow-sm transition-all duration-200 flex items-center gap-2 cursor-pointer">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
            + Tambah Mitra Baru
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if(session('success')): ?>
    <div class="mb-6 bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 px-4 py-3 rounded-xl flex items-center justify-between text-xs font-semibold">
        <div class="flex items-center gap-2">
            <svg class="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            <span><?php echo e(session('success')); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
    <div class="mb-6 bg-rose-500/10 border border-rose-500/20 text-rose-700 px-4 py-3 rounded-xl text-xs font-semibold">
        <ul class="list-disc pl-5 space-y-1">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- Stat Cards Overview -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5m0 0h4m-4 0V11m0 0h4m-4 0H9m4 0V7m0 0h4m-4 0H9"></path></svg>
            </div>
            <div>
                <span class="text-[11px] text-slate-500 font-bold uppercase tracking-wider block">Total Mitra</span>
                <span class="text-xl font-extrabold text-slate-800"><?php echo e($stats['total']); ?></span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </div>
            <div>
                <span class="text-[11px] text-slate-500 font-bold uppercase tracking-wider block">Mitra Aktif</span>
                <span class="text-xl font-extrabold text-teal-600"><?php echo e($stats['active']); ?></span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z"></path></svg>
            </div>
            <div>
                <span class="text-[11px] text-slate-500 font-bold uppercase tracking-wider block">Pemerintah & BUMN</span>
                <span class="text-xl font-extrabold text-blue-600"><?php echo e($stats['gov_bumn']); ?></span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0112 20.055a11.952 11.952 0 01-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path></svg>
            </div>
            <div>
                <span class="text-[11px] text-slate-500 font-bold uppercase tracking-wider block">Swasta & Pendidikan</span>
                <span class="text-xl font-extrabold text-purple-600"><?php echo e($stats['private_edu']); ?></span>
            </div>
        </div>
    </div>

    <!-- Filter & Search Bar -->
    <div class="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs mb-6 flex flex-col md:flex-row items-center justify-between gap-4">
        
        <!-- Category Filter Tabs -->
        <div class="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
            <a href="<?php echo e(route('dashboard.partnerships.index', ['category' => 'all', 'search' => $search])); ?>" 
               class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap <?php echo e($categoryFilter === 'all' ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'); ?>">
               Semua Kategori
            </a>
            <a href="<?php echo e(route('dashboard.partnerships.index', ['category' => 'Instansi Pemerintah', 'search' => $search])); ?>" 
               class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap <?php echo e($categoryFilter === 'Instansi Pemerintah' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'); ?>">
               Pemerintah
            </a>
            <a href="<?php echo e(route('dashboard.partnerships.index', ['category' => 'BUMN / BUMD', 'search' => $search])); ?>" 
               class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap <?php echo e($categoryFilter === 'BUMN / BUMD' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'); ?>">
               BUMN / BUMD
            </a>
            <a href="<?php echo e(route('dashboard.partnerships.index', ['category' => 'Pendidikan', 'search' => $search])); ?>" 
               class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap <?php echo e($categoryFilter === 'Pendidikan' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'); ?>">
               Pendidikan
            </a>
            <a href="<?php echo e(route('dashboard.partnerships.index', ['category' => 'Sektor Swasta / UMKM', 'search' => $search])); ?>" 
               class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap <?php echo e($categoryFilter === 'Sektor Swasta / UMKM' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'); ?>">
               Swasta / UMKM
            </a>
        </div>

        <!-- Search Input Form -->
        <form action="<?php echo e(route('dashboard.partnerships.index')); ?>" method="GET" class="w-full md:w-72 relative">
            <input type="hidden" name="category" value="<?php echo e($categoryFilter); ?>">
            <input type="text" 
                   name="search" 
                   value="<?php echo e($search); ?>" 
                   placeholder="Cari nama mitra/kontak..." 
                   class="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition">
            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            </div>
        </form>
    </div>

    <!-- Main Data Table / Cards -->
    <?php if($partnerships->count() > 0): ?>
    <div class="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden mb-6">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-slate-900 text-white text-[11px] font-bold uppercase tracking-wider border-b border-slate-800">
                        <th class="py-3.5 px-4">Nama & Logo Mitra</th>
                        <th class="py-3.5 px-4">Kategori</th>
                        <th class="py-3.5 px-4">Deskripsi Kerjasama</th>
                        <th class="py-3.5 px-4">Kontak Person</th>
                        <th class="py-3.5 px-4 text-center">Status</th>
                        <th class="py-3.5 px-4 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-xs">
                    <?php $__currentLoopData = $partnerships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-slate-50/80 transition">
                        
                        <!-- Logo & Name -->
                        <td class="py-3.5 px-4">
                            <div class="flex items-center gap-3">
                                <div class="w-11 h-11 rounded-xl bg-slate-100 border border-slate-200 p-1 shrink-0 overflow-hidden flex items-center justify-center">
                                    <img src="<?php echo e($partner->logo); ?>" alt="<?php echo e($partner->name); ?>" class="w-full h-full object-contain rounded-lg">
                                </div>
                                <div class="min-w-0">
                                    <h4 class="font-bold text-slate-800 leading-snug line-clamp-1"><?php echo e($partner->name); ?></h4>
                                    <?php if($partner->website): ?>
                                    <a href="<?php echo e($partner->website); ?>" target="_blank" class="text-[11px] text-emerald-600 hover:underline flex items-center gap-1 mt-0.5">
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                                        <?php echo e(parse_url($partner->website, PHP_URL_HOST) ?? $partner->website); ?>

                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>

                        <!-- Category -->
                        <td class="py-3.5 px-4 whitespace-nowrap">
                            <span class="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200/80 rounded-lg text-[10px] font-extrabold uppercase tracking-wider">
                                <?php echo e($partner->category); ?>

                            </span>
                        </td>

                        <!-- Description -->
                        <td class="py-3.5 px-4 max-w-xs">
                            <p class="text-slate-600 line-clamp-2 leading-relaxed text-[11px]">
                                <?php echo e($partner->description ?? '-'); ?>

                            </p>
                        </td>

                        <!-- Contact Person & Phone -->
                        <td class="py-3.5 px-4 whitespace-nowrap">
                            <div class="flex flex-col">
                                <span class="font-bold text-slate-700"><?php echo e($partner->contact_person ?? '-'); ?></span>
                                <?php if($partner->phone): ?>
                                <span class="text-[11px] text-slate-500 font-mono flex items-center gap-1 mt-0.5">
                                    <svg class="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h32a2 2 0 012 2v2a2 2 0 01-2 2H5a2 2 0 01-2-2V5z"></path></svg>
                                    <?php echo e($partner->phone); ?>

                                </span>
                                <?php endif; ?>
                            </div>
                        </td>

                        <!-- Status -->
                        <td class="py-3.5 px-4 text-center whitespace-nowrap">
                            <?php if($partner->is_active): ?>
                            <span class="px-2.5 py-1 bg-teal-100 text-teal-800 rounded-full text-[10px] font-bold">
                                Aktif
                            </span>
                            <?php else: ?>
                            <span class="px-2.5 py-1 bg-slate-100 text-slate-500 rounded-full text-[10px] font-bold">
                                Nonaktif
                            </span>
                            <?php endif; ?>
                        </td>

                        <!-- Actions -->
                        <td class="py-3.5 px-4 text-right whitespace-nowrap">
                            <div class="flex items-center justify-end gap-2">
                                <button @click="openEdit(<?php echo e(json_encode($partner)); ?>)" 
                                        class="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition" title="Edit Data">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                </button>
                                <button @click="openDelete(<?php echo e($partner->id); ?>, '<?php echo e(addslashes($partner->name)); ?>')" 
                                        class="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition" title="Hapus Data">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div>
        <?php echo e($partnerships->withQueryString()->links()); ?>

    </div>
    <?php else: ?>
    <div class="bg-white rounded-2xl p-12 text-center border border-slate-200 max-w-xl mx-auto my-8">
        <svg class="w-16 h-16 text-slate-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5m0 0h4m-4 0V11m0 0h4m-4 0H9m4 0V7m0 0h4m-4 0H9"></path></svg>
        <h3 class="text-lg font-bold text-slate-700">Belum Ada Data Kemitraan</h3>
        <p class="text-slate-500 text-xs mt-1">Belum ada data mitra kerja yang sesuai dengan filter atau pencarian Anda.</p>
    </div>
    <?php endif; ?>

    <!-- MODAL CREATE PARTNER -->
    <div x-show="createModal" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         @keydown.escape.window="createModal = false"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs"
         style="display: none;">
        
        <div @click.away="createModal = false" class="relative max-w-lg w-full bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div class="p-5 bg-slate-900 text-white flex items-center justify-between">
                <h3 class="font-bold text-base flex items-center gap-2">
                    <svg class="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                    Tambah Mitra Kerja Baru
                </h3>
                <button @click="createModal = false" class="text-slate-400 hover:text-white transition cursor-pointer">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>

            <form action="<?php echo e(route('dashboard.partnerships.store')); ?>" method="POST" enctype="multipart/form-data" class="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                <?php echo csrf_field(); ?>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Nama Instansi / Perusahaan Mitra <span class="text-red-500">*</span></label>
                    <input type="text" name="name" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition" placeholder="Contoh: PT Pegadaian (Persero)">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Kategori <span class="text-red-500">*</span></label>
                        <select name="category" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition bg-white">
                            <option value="Instansi Pemerintah">Instansi Pemerintah</option>
                            <option value="BUMN / BUMD">BUMN / BUMD</option>
                            <option value="Pendidikan">Pendidikan</option>
                            <option value="Sektor Swasta / UMKM">Sektor Swasta / UMKM</option>
                            <option value="Organisasi Masyarakat">Organisasi Masyarakat</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Urutan Tampilan</label>
                        <input type="number" name="sort_order" value="0" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Upload File Logo (Atau Masukkan URL Logo)</label>
                    <input type="file" name="logo_file" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-emerald-100 file:text-emerald-800 hover:file:bg-emerald-200 transition cursor-pointer mb-2">
                    <input type="text" name="logo_url" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition" placeholder="Atau paste URL logo (https://...)">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Deskripsi / Bentuk Kerjasama</label>
                    <textarea name="description" rows="2" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition" placeholder="Penjelasan ringkas program kemitraan..."></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Penanggung Jawab / Kontak</label>
                        <input type="text" name="contact_person" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition" placeholder="Contoh: Bpk. Hendra">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">No. Telepon / WA</label>
                        <input type="text" name="phone" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition" placeholder="081234567890">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Situs Web Resmi (URL)</label>
                    <input type="url" name="website" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition" placeholder="https://www.instansi.go.id">
                </div>

                <div class="flex items-center gap-2 pt-2">
                    <input type="checkbox" name="is_active" id="is_active_create" value="1" checked class="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500">
                    <label for="is_active_create" class="text-xs font-bold text-slate-700 cursor-pointer">Status Aktif (Ditampilkan Publik)</label>
                </div>

                <div class="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                    <button type="button" @click="createModal = false" class="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition cursor-pointer">Batal</button>
                    <button type="submit" class="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition cursor-pointer">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL EDIT PARTNER -->
    <div x-show="editModal" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         @keydown.escape.window="editModal = false"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs"
         style="display: none;">
        
        <div @click.away="editModal = false" class="relative max-w-lg w-full bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div class="p-5 bg-slate-900 text-white flex items-center justify-between">
                <h3 class="font-bold text-base flex items-center gap-2">
                    <svg class="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                    Edit Data Mitra Kerja
                </h3>
                <button @click="editModal = false" class="text-slate-400 hover:text-white transition cursor-pointer">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>

            <form :action="'<?php echo e(url('/dashboard/partnerships')); ?>/' + editPartner.id" method="POST" enctype="multipart/form-data" class="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Nama Instansi / Perusahaan Mitra <span class="text-red-500">*</span></label>
                    <input type="text" name="name" x-model="editPartner.name" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Kategori <span class="text-red-500">*</span></label>
                        <select name="category" x-model="editPartner.category" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition bg-white">
                            <option value="Instansi Pemerintah">Instansi Pemerintah</option>
                            <option value="BUMN / BUMD">BUMN / BUMD</option>
                            <option value="Pendidikan">Pendidikan</option>
                            <option value="Sektor Swasta / UMKM">Sektor Swasta / UMKM</option>
                            <option value="Organisasi Masyarakat">Organisasi Masyarakat</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Urutan Tampilan</label>
                        <input type="number" name="sort_order" x-model="editPartner.sort_order" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Ganti File Logo (Opsional)</label>
                    <input type="file" name="logo_file" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-emerald-100 file:text-emerald-800 hover:file:bg-emerald-200 transition cursor-pointer mb-2">
                    <input type="text" name="logo_url" x-model="editPartner.logo_url" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition" placeholder="Atau paste URL logo (https://...)">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Deskripsi / Bentuk Kerjasama</label>
                    <textarea name="description" x-model="editPartner.description" rows="2" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Penanggung Jawab / Kontak</label>
                        <input type="text" name="contact_person" x-model="editPartner.contact_person" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">No. Telepon / WA</label>
                        <input type="text" name="phone" x-model="editPartner.phone" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Situs Web Resmi (URL)</label>
                    <input type="url" name="website" x-model="editPartner.website" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 transition">
                </div>

                <div class="flex items-center gap-2 pt-2">
                    <input type="checkbox" name="is_active" id="is_active_edit" value="1" :checked="editPartner.is_active" class="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500">
                    <label for="is_active_edit" class="text-xs font-bold text-slate-700 cursor-pointer">Status Aktif (Ditampilkan Publik)</label>
                </div>

                <div class="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                    <button type="button" @click="editModal = false" class="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition cursor-pointer">Batal</button>
                    <button type="submit" class="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition cursor-pointer">Perbarui Data</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL DELETE CONFIRMATION -->
    <div x-show="deleteModal" 
         x-transition.opacity
         @keydown.escape.window="deleteModal = false"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs"
         style="display: none;">
        
        <div @click.away="deleteModal = false" class="relative max-w-sm w-full bg-white rounded-2xl p-6 text-center shadow-2xl border border-slate-200">
            <div class="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            </div>
            <h3 class="font-bold text-base text-slate-800 mb-1">Konfirmasi Hapus</h3>
            <p class="text-xs text-slate-500 mb-6">Apakah Anda yakin ingin menghapus data kemitraan <span class="font-bold text-slate-700" x-text="deletePartnerName"></span>?</p>
            
            <form :action="deleteFormAction" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="flex items-center justify-center gap-3">
                    <button type="button" @click="deleteModal = false" class="w-1/2 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition cursor-pointer">Batal</button>
                    <button type="submit" class="w-1/2 py-2.5 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-sm transition cursor-pointer">Ya, Hapus</button>
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\portal-desa\webkel-sidomukti\resources\views/dashboard/partnerships/index.blade.php ENDPATH**/ ?>