<?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr class="hover:bg-slate-50/80 transition">
    <!-- Waktu -->
    <td class="p-4 whitespace-nowrap text-slate-500 font-medium">
        <div><?php echo e($log->created_at->format('d M Y')); ?></div>
        <div class="text-[11px] text-slate-400"><?php echo e($log->created_at->format('H:i:s')); ?> WIB</div>
    </td>

    <!-- Pengguna -->
    <td class="p-4 whitespace-nowrap">
        <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
                <?php echo e(strtoupper(substr($log->user_name, 0, 1))); ?>

            </div>
            <div class="flex flex-col">
                <span class="font-bold text-slate-800"><?php echo e($log->user_name); ?></span>
                <?php if($log->user_role === 'admin'): ?>
                    <span class="text-[9px] font-extrabold uppercase text-purple-600">Admin</span>
                <?php elseif($log->user_role === 'staf'): ?>
                    <span class="text-[9px] font-extrabold uppercase text-blue-600">Staf</span>
                <?php else: ?>
                    <span class="text-[9px] font-extrabold uppercase text-slate-400">Guest</span>
                <?php endif; ?>
            </div>
        </div>
    </td>

    <!-- Modul -->
    <td class="p-4 whitespace-nowrap">
        <span class="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-bold text-[11px]">
            <?php echo e($log->module); ?>

        </span>
    </td>

    <!-- Aksi Badge -->
    <td class="p-4 whitespace-nowrap">
        <?php switch($log->action):
            case ('CREATE'): ?>
                <span class="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-[10px] uppercase tracking-wider">CREATE</span>
                <?php break; ?>
            <?php case ('UPDATE'): ?>
                <span class="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 font-extrabold text-[10px] uppercase tracking-wider">UPDATE</span>
                <?php break; ?>
            <?php case ('DELETE'): ?>
                <span class="px-2.5 py-1 rounded-full bg-rose-100 text-rose-800 font-extrabold text-[10px] uppercase tracking-wider">DELETE</span>
                <?php break; ?>
            <?php case ('LOGIN'): ?>
                <span class="px-2.5 py-1 rounded-full bg-sky-100 text-sky-800 font-extrabold text-[10px] uppercase tracking-wider">LOGIN</span>
                <?php break; ?>
            <?php case ('LOGOUT'): ?>
                <span class="px-2.5 py-1 rounded-full bg-slate-200 text-slate-700 font-extrabold text-[10px] uppercase tracking-wider">LOGOUT</span>
                <?php break; ?>
            <?php case ('UPDATE_STATUS'): ?>
                <span class="px-2.5 py-1 rounded-full bg-indigo-100 text-indigo-800 font-extrabold text-[10px] uppercase tracking-wider">STATUS</span>
                <?php break; ?>
            <?php default: ?>
                <span class="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 font-extrabold text-[10px] uppercase tracking-wider"><?php echo e($log->action); ?></span>
        <?php endswitch; ?>
    </td>

    <!-- Deskripsi -->
    <td class="p-4 font-medium text-slate-700 max-w-md">
        <?php echo e($log->description); ?>

    </td>

    <!-- IP Address -->
    <td class="p-4 whitespace-nowrap text-slate-500 font-mono text-[11px]">
        <?php echo e($log->ip_address ?? '-'); ?>

    </td>

    <!-- Detail Button -->
    <td class="p-4 whitespace-nowrap text-center">
        <button @click="selectedLog = <?php echo e(json_encode($log)); ?>" 
                class="p-2 bg-slate-100 hover:bg-emerald-50 text-slate-600 hover:text-emerald-600 rounded-lg transition" 
                title="Lihat Rincian Meta">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
            </svg>
        </button>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    <td colspan="7" class="p-12 text-center text-slate-400">
        <svg class="w-12 h-12 mx-auto text-slate-300 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
        </svg>
        <p class="font-bold text-sm text-slate-600">Tidak ada log aktivitas ditemukan</p>
        <p class="text-xs text-slate-400 mt-1">Coba atur ulang kata kunci atau filter pencarian Anda.</p>
    </td>
</tr>
<?php endif; ?>
<?php /**PATH D:\portal-desa\webkel-sidomukti\resources\views/dashboard/activity-logs/partials/table_body.blade.php ENDPATH**/ ?>