@extends('layouts.app')

@section('content')

<!-- Hero Banner -->
<section class="relative bg-slate-950 h-[520px] md:h-[600px] w-full overflow-hidden">
    <!-- Background Image -->
    @php
        $heroBgVal = $settings['hero_background'] ?? null;
        $heroBg = !empty($heroBgVal) 
            ? (\Illuminate\Support\Str::startsWith($heroBgVal, ['http://', 'https://']) ? $heroBgVal : Storage::url($heroBgVal)) 
            : asset('hero-bg.jpg');
    @endphp
    <img src="{{ $heroBg }}" class="absolute inset-0 w-full h-full object-cover object-center opacity-95 transition-opacity duration-500" alt="Pelayanan Publik Digital Kelurahan Sidomukti">
    
    <!-- Smooth Soft Gradient Overlay -->
    <div class="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-slate-950/45 to-transparent"></div>
    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-slate-950/20"></div>
    
    <div class="container mx-auto px-4 h-full relative z-10 flex items-center">
        <div class="w-full md:w-2/3 lg:w-1/2 text-white">
            <div class="hero-animate hero-animate-delay-1 inline-flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-green-600 to-[#00A859] text-white text-[11px] font-bold tracking-widest uppercase shadow-lg shadow-green-500/20 mb-6 border-l-4 border-yellow-400 rounded-r-full">
                Program Unggulan Kelurahan
            </div>
            
            <h2 class="hero-animate hero-animate-delay-2 text-4xl md:text-5xl lg:text-[56px] font-extrabold leading-[1.1] mb-5 text-white tracking-tight">
                {!! $settings['hero_title_1'] ?? 'Pelayanan Publik' !!}
                <span class="block text-[#00A859] mt-1">{!! $settings['hero_title_2'] ?? 'Berbasis Digital Cepat & <br class="hidden md:block" /> Transparan' !!}</span>
            </h2>
            
            <div class="hero-animate hero-animate-delay-3 w-20 h-1.5 bg-gradient-to-r from-yellow-400 to-yellow-500 mb-8 rounded-full shadow-[0_0_10px_rgba(250,204,21,0.4)]"></div>
            
            <p class="hero-animate hero-animate-delay-3 text-base md:text-lg text-slate-300 mb-8 font-normal leading-relaxed max-w-lg">
                {{ $settings['hero_subtitle'] ?? 'Kini administrasi kependudukan lebih cepat dan transparan melalui integrasi digital.' }}
            </p>
            
            <div class="hero-animate hero-animate-delay-4 flex flex-wrap gap-3">
                <a href="#layanan" class="px-8 py-3.5 bg-gradient-to-r from-green-500 to-[#00A859] hover:from-green-600 hover:to-green-800 text-white font-extrabold rounded-full shadow-lg shadow-green-500/30 hover:-translate-y-1 transition-all duration-300 flex items-center gap-2 text-sm uppercase tracking-wide inline-flex">
                    Layanan Mandiri
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Sambutan Pimpinan / Lurah -->
<section class="py-16 bg-white">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col lg:flex-row gap-12 items-center">
            <div class="w-full lg:w-1/3 flex justify-center reveal fade-right">
                <div class="relative w-64">
                    @php
                        $kadinVal = $settings['kadin_photo'] ?? $settings['foto_lurah'] ?? null;
                        $kadinPhoto = !empty($kadinVal) 
                            ? (\Illuminate\Support\Str::startsWith($kadinVal, ['http://', 'https://']) ? $kadinVal : Storage::url($kadinVal)) 
                            : 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=600&auto=format&fit=crop';
                    @endphp
                    <img src="{{ $kadinPhoto }}" 
                         alt="Pimpinan Kelurahan" class="w-full h-80 object-cover rounded-2xl shadow-lg border border-slate-100">
                    <div class="absolute -bottom-4 inset-x-4 bg-white border border-slate-100 py-3 px-4 rounded-xl shadow-sm text-center">
                        <h4 class="font-bold text-sm text-slate-800">{{ $settings['kadin_name'] ?? $settings['nama_lurah'] ?? 'H. Ahmad Syarif, S.STP, M.Si' }}</h4>
                        <p class="text-[10px] text-green-600 font-semibold uppercase mt-0.5">{{ $settings['kadin_title'] ?? 'LURAH SIDOMUKTI' }}</p>
                    </div>
                </div>
            </div>

            <div class="w-full lg:w-2/3 space-y-5 text-center lg:text-left reveal fade-left">
                <div class="inline-flex items-center gap-2 text-green-600 text-xs font-bold uppercase tracking-widest">
                    Sambutan {{ $settings['kadin_title'] ?? 'LURAH SIDOMUKTI' }}
                </div>
                <h2 class="text-2xl sm:text-3xl font-bold text-slate-900 leading-tight">
                    Melayani Warga Sepenuh Hati Menuju Kelurahan yang Maju, Sejahtera & Mandiri
                </h2>
                <p class="text-slate-600 text-sm leading-relaxed max-w-3xl">
                    Selamat Datang di Portal Resmi <strong>{{ $settings['agency_name'] ?? 'KELURAHAN SIDOMUKTI' }} {{ $settings['regency_name'] ?? 'Kecamatan Kraksaan, Kabupaten Probolinggo' }}</strong>. Kami berkomitmen menyajikan pelayanan publik prima, kemudahan administrasi kependudukan dan pengurusan surat keterangan, transparansi kinerja kelurahan, serta pemberdayaan potensi ekonomi warga lokal.
                </p>
                <div class="pt-4 flex flex-wrap gap-4 items-center justify-center lg:justify-start">
                    <a href="{{ route('profil.visi-misi') }}" class="px-5 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold text-sm transition-colors flex items-center gap-2">
                        Visi & Misi Kami <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Floating Stats Bar -->
<section class="relative z-20 py-12 bg-slate-50 border-t border-slate-100">
    <div class="container mx-auto px-4">
        <div class="bg-white rounded-2xl shadow-xl border border-slate-100 p-6 md:p-0 grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-0 md:divide-x divide-slate-100">
            <div class="md:p-6 text-center group reveal fade-up" data-delay="0">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-green-50 text-green-600 mb-3 group-hover:bg-green-600 group-hover:text-white transition-all duration-300">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </div>
                <div class="text-2xl md:text-3xl font-extrabold text-slate-800" data-count-to="{{ $settings['demografi_total'] ?? ($settings['jumlah_penduduk'] ?? '2776') }}" data-count-suffix="">0</div>
                <p class="text-xs text-slate-500 font-semibold uppercase tracking-wider mt-1">Jumlah Penduduk</p>
            </div>
            <div class="md:p-6 text-center group reveal fade-up" data-delay="100">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-amber-50 text-amber-600 mb-3 group-hover:bg-amber-600 group-hover:text-white transition-all duration-300">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div class="text-2xl md:text-3xl font-extrabold text-slate-800" data-count-to="{{ $settings['permohonan_selesai'] ?? '1247' }}" data-count-suffix="">0</div>
                <p class="text-xs text-slate-500 font-semibold uppercase tracking-wider mt-1">Permohonan Selesai</p>
            </div>
            <div class="md:p-6 text-center group reveal fade-up" data-delay="200">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 mb-3 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div class="text-2xl md:text-3xl font-extrabold text-green-600" data-count-to="{{ $settings['tingkat_kepuasan'] ?? '98' }}" data-count-suffix="%">0</div>
                <p class="text-xs text-slate-500 font-semibold uppercase tracking-wider mt-1">Tingkat Kepuasan</p>
            </div>
        </div>
    </div>
</section>

<!-- Standar Pelayanan & SOP (Grid) -->
<section id="layanan" class="py-16 bg-white relative z-10 border-b border-slate-100" x-data="{ searchQuery: '' }">
    <div class="container mx-auto px-4">
        <div class="text-center mb-10 reveal fade-up">
            <span class="inline-flex items-center gap-2 px-4 py-1.5 bg-emerald-50 text-emerald-700 text-[11px] font-extrabold tracking-widest uppercase rounded-full mb-4 border border-emerald-200/60 shadow-xs">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                Standar Pelayanan Publik
            </span>
            <h2 class="text-3xl md:text-4xl font-extrabold text-[#111827]">Standar Operasional Prosedur (SOP)</h2>
            <p class="text-slate-500 mt-3 font-medium max-w-xl mx-auto">Panduan resmi alur kepengurusan administrasi dan berkas persyaratan pelayanan masyarakat di Kelurahan Sidomukti.</p>
            <div class="w-20 h-[3px] bg-[#008c5f] mx-auto mt-4"></div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            @if(isset($services) && $services->count() > 0)
                @foreach($services as $index => $service)
                <div class="reveal fade-up" data-delay="{{ $index * 80 }}">
                    <div class="bg-white border-2 border-slate-100 hover:border-emerald-400 hover:shadow-xl rounded-2xl p-6 flex flex-col items-center text-center transition-all duration-300 hover:-translate-y-2 group h-full justify-between">
                        <div>
                            <div class="w-14 h-14 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl shadow-sm flex items-center justify-center text-emerald-700 group-hover:bg-gradient-to-br group-hover:from-emerald-600 group-hover:to-teal-600 group-hover:text-white group-hover:shadow-lg group-hover:shadow-emerald-600/30 transition-all duration-300 mb-4 mx-auto font-bold text-sm">
                                {{ $service->order ?? $loop->iteration }}
                            </div>
                            <h3 class="font-bold text-sm text-slate-800 mb-2 group-hover:text-emerald-700 transition line-clamp-2">{{ $service->title }}</h3>
                            <p class="text-xs text-slate-500 leading-relaxed line-clamp-3 mb-4">{{ $service->description ?? 'Pedoman operasional standar pelayanan administrasi masyarakat kelurahan.' }}</p>
                        </div>
                        <a href="{{ route('services.show', $service->slug) }}" class="mt-2 w-full py-2.5 bg-slate-50 border-2 border-emerald-500/30 text-emerald-700 font-bold text-xs uppercase tracking-wider rounded-xl group-hover:bg-emerald-600 group-hover:border-emerald-600 group-hover:text-white transition-all duration-300 block hover:shadow-lg hover:shadow-emerald-600/20">Lihat Dokumen SOP</a>
                    </div>
                </div>
                @endforeach
            @endif
        </div>

        <div class="mt-10 text-center reveal fade-up">
            <a href="{{ route('services.index') }}" class="inline-flex items-center gap-2 px-8 py-3.5 bg-white border-2 border-emerald-600 text-emerald-700 hover:bg-emerald-600 hover:text-white font-extrabold rounded-full transition-all duration-300 shadow hover:-translate-y-1 hover:shadow-lg uppercase tracking-wide text-sm">
                Lihat Dokumen SOP Selengkapnya
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
            </a>
        </div>
    </div>
</section>

<!-- Feed Informasi Berita & Maklumat Pelayanan (Sejajar) -->
<section id="berita" class="py-16 bg-slate-50 border-b border-slate-200/80">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Kolom Kiri: Berita & Informasi (lg:col-span-7) -->
            <div class="lg:col-span-7 flex flex-col justify-between h-full">
                <div>
                    <div class="flex justify-between items-end mb-6 pb-2 border-b-2 border-slate-200 reveal fade-up">
                        <div>
                            <span class="inline-flex items-center gap-2 px-3 py-1 bg-green-50 text-green-700 text-[10px] font-bold tracking-widest uppercase rounded-full mb-2 border border-green-200/60">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path></svg>
                                Kabar Terkini
                            </span>
                            <h2 class="text-2xl font-extrabold text-slate-800 border-b-4 border-green-600 pb-2 -mb-[10px] inline-block">Berita & Informasi</h2>
                        </div>
                        <a href="{{ route('posts.index') }}" class="hidden sm:flex text-xs font-bold text-green-700 hover:text-green-800 transition items-center gap-1 uppercase tracking-wide bg-green-50 px-3.5 py-1.5 rounded-lg hover:bg-green-100 border border-green-200">
                            Indeks Berita <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                        </a>
                    </div>

                    @if(isset($posts) && $posts->count() > 0)
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        @foreach($posts->take(4) as $index => $post)
                        <article class="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden hover:shadow-xl transition duration-300 group flex flex-col h-full reveal fade-up" data-delay="{{ $index * 80 }}">
                            <div class="relative h-40 overflow-hidden bg-slate-200 shrink-0">
                                <img src="{{ $post->thumbnail ? Storage::url($post->thumbnail) : 'https://images.unsplash.com/photo-1544396821-4dd40b938ad3?q=80&w=600&auto=format&fit=crop' }}" alt="{{ $post->title }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                                <div class="absolute top-3 left-3 flex flex-col text-center shadow-lg rounded-lg overflow-hidden">
                                    <span class="bg-green-600 text-white font-extrabold text-base px-2.5 py-0.5">{{ \Carbon\Carbon::parse($post->published_at)->format('d') }}</span>
                                    <span class="bg-white text-slate-800 text-[9px] font-bold uppercase px-2 py-0.5 leading-none tracking-wider">{{ \Carbon\Carbon::parse($post->published_at)->format('M Y') }}</span>
                                </div>
                                @if($index === 0)
                                <div class="absolute top-3 right-3">
                                    <span class="bg-yellow-500 text-slate-900 text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider shadow">Terbaru</span>
                                </div>
                                @endif
                            </div>
                            <div class="p-4 flex flex-col flex-grow">
                                <span class="inline-flex items-center gap-1 text-[10px] font-bold text-green-600 uppercase tracking-wider mb-1.5">
                                    <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span> Pemerintahan
                                </span>
                                <a href="{{ route('posts.show', $post->slug) }}">
                                    <h3 class="font-bold text-sm text-slate-800 leading-snug mb-2 group-hover:text-green-700 transition line-clamp-2">{{ $post->title }}</h3>
                                </a>
                                <p class="text-xs text-slate-500 line-clamp-2 mb-3 flex-grow leading-relaxed">{{ Str::limit(strip_tags($post->content), 75) }}</p>
                                <div class="mt-auto pt-2.5 border-t border-slate-100 flex items-center justify-between">
                                    <a href="{{ route('posts.show', $post->slug) }}" class="inline-flex items-center gap-1 text-xs font-bold text-green-600 hover:text-green-700 transition">
                                        Baca Selengkapnya <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                                    </a>
                                </div>
                            </div>
                        </article>
                        @endforeach
                    </div>
                    @else
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        @foreach([1, 2, 3, 4] as $index => $i)
                        <article class="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden hover:shadow-xl transition duration-300 group flex flex-col h-full reveal fade-up" data-delay="{{ $index * 80 }}">
                            <div class="relative h-40 overflow-hidden bg-slate-200 shrink-0">
                                <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=600&auto=format&fit=crop&sig={{$i}}" alt="Berita Dummy" class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                                <div class="absolute top-3 left-3 flex flex-col text-center shadow-lg rounded-lg overflow-hidden">
                                    <span class="bg-green-600 text-white font-extrabold text-base px-2.5 py-0.5">{{ 10 + $i }}</span>
                                    <span class="bg-white text-slate-800 text-[9px] font-bold uppercase px-2 py-0.5 leading-none tracking-wider">Sep 2026</span>
                                </div>
                            </div>
                            <div class="p-4 flex flex-col flex-grow">
                                <span class="inline-flex items-center gap-1 text-[10px] font-bold text-green-600 uppercase tracking-wider mb-1.5">
                                    <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span> Informasi Publik
                                </span>
                                <a href="#"><h3 class="font-bold text-sm text-slate-800 leading-snug mb-2 group-hover:text-green-700 transition line-clamp-2">Rapat Koordinasi Kelurahan Terkait Pelayanan {{$i}}</h3></a>
                                <p class="text-xs text-slate-500 line-clamp-2 mb-3 flex-grow leading-relaxed">Kelurahan Sidomukti mengadakan rapat koordinasi bersama tokoh masyarakat...</p>
                                <div class="mt-auto pt-2.5 border-t border-slate-100">
                                    <a href="#" class="inline-flex items-center gap-1 text-xs font-bold text-green-600 hover:text-green-800 transition">Baca Selengkapnya <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg></a>
                                </div>
                            </div>
                        </article>
                        @endforeach
                    </div>
                    @endif
                </div>

                <div class="mt-6 text-center sm:hidden">
                    <a href="{{ route('posts.index') }}" class="inline-flex text-xs font-bold text-white transition items-center gap-2 uppercase tracking-wide bg-green-600 hover:bg-green-700 px-5 py-2.5 rounded-xl shadow">Semua Berita <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg></a>
                </div>
            </div>

            <!-- Kolom Kanan: Maklumat Pelayanan (lg:col-span-5) -->
            <div class="lg:col-span-5 flex flex-col h-full reveal fade-up" data-delay="150">
                <div class="flex justify-between items-end mb-6 pb-2 border-b-2 border-slate-200">
                    <div>
                        <span class="inline-flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-bold tracking-widest uppercase rounded-full mb-2 border border-emerald-200/60">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
                            Komitmen Layanan Publik
                        </span>
                        <h2 class="text-2xl font-extrabold text-slate-800 border-b-4 border-emerald-600 pb-2 -mb-[10px] inline-block">Maklumat Pelayanan</h2>
                    </div>
                </div>

                @if(isset($maklumat) && $maklumat)
                <!-- Executive Certificate Style Maklumat Card -->
                <div class="bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 rounded-3xl p-6 sm:p-7 text-white shadow-2xl border-2 border-emerald-500/30 relative overflow-hidden flex flex-col justify-between flex-grow group">
                    <!-- Background Watermark Pattern -->
                    <div class="absolute -right-8 -bottom-8 opacity-10 pointer-events-none group-hover:scale-105 transition-transform duration-700">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/e/e6/Logo_Kabupaten_Probolinggo_-_Seal_of_Probolinggo_Regency.svg" class="w-64 h-64 object-contain filter grayscale invert" alt="Logo Watermark">
                    </div>

                    <div>
                        <!-- Header Logo & Badge -->
                        <div class="flex items-center justify-between gap-3 mb-5 border-b border-emerald-500/20 pb-4">
                            <div class="flex items-center gap-3">
                                <img src="https://upload.wikimedia.org/wikipedia/commons/e/e6/Logo_Kabupaten_Probolinggo_-_Seal_of_Probolinggo_Regency.svg" class="w-10 h-10 object-contain bg-white rounded-xl p-1.5 shadow-md border border-white/30" alt="Logo Probolinggo">
                                <div>
                                    <span class="block text-[10px] font-black text-emerald-400 uppercase tracking-widest leading-none">Pemerintah Kab. Probolinggo</span>
                                    <span class="block text-xs font-bold text-white uppercase tracking-wider mt-0.5">Kelurahan Sidomukti</span>
                                </div>
                            </div>
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 tracking-wider">
                                Resmi
                            </span>
                        </div>

                        <!-- Maklumat Title & Subtitle -->
                        <h3 class="text-xl font-black text-white tracking-tight leading-snug mb-1">
                            {{ $maklumat->title }}
                        </h3>
                        @if($maklumat->subtitle)
                            <p class="text-xs font-bold text-emerald-300 tracking-wide mb-4">{{ $maklumat->subtitle }}</p>
                        @endif

                        <!-- Main Statement Box -->
                        <div class="relative bg-white/5 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-white/10 my-4 text-slate-200 text-xs sm:text-sm leading-relaxed italic shadow-inner">
                            <span class="text-3xl text-emerald-400/40 font-serif leading-none absolute top-2 left-3">“</span>
                            <p class="px-3 py-1 relative z-10">{{ $maklumat->content }}</p>
                            <span class="text-3xl text-emerald-400/40 font-serif leading-none absolute bottom-0 right-3">”</span>
                        </div>
                    </div>

                    <!-- Signer & Poster Section -->
                    <div class="pt-4 border-t border-emerald-500/20 flex flex-col sm:flex-row sm:items-end justify-between gap-4 mt-auto">
                        <div class="space-y-1">
                            <div class="flex items-center gap-1.5 text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                                <svg class="w-3.5 h-3.5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                                Tertanda & Disahkan Oleh:
                            </div>
                            <div class="text-sm font-extrabold text-white tracking-wide">{{ $maklumat->signer_name ?? 'Lurah Sidomukti' }}</div>
                            <div class="text-xs text-emerald-400 font-semibold">{{ $maklumat->signer_title ?? 'Kepala Kelurahan Sidomukti' }}</div>
                        </div>

                        @if($maklumat->image)
                        <div class="shrink-0 self-start sm:self-auto">
                            <a href="{{ asset('storage/' . $maklumat->image) }}" target="_blank" class="block group/img relative rounded-xl overflow-hidden border border-white/20 shadow-lg">
                                <img src="{{ asset('storage/' . $maklumat->image) }}" alt="Lampiran Maklumat" class="w-16 h-16 object-cover group-hover/img:scale-110 transition duration-300">
                                <div class="absolute inset-0 bg-slate-950/40 opacity-0 group-hover/img:opacity-100 transition flex items-center justify-center text-white">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7"></path></svg>
                                </div>
                            </a>
                        </div>
                        @endif
                    </div>
                </div>
                @else
                <div class="bg-white rounded-3xl p-8 text-center border-2 border-dashed border-slate-200 text-slate-400 flex-grow flex flex-col items-center justify-center">
                    <svg class="w-12 h-12 text-slate-300 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 01-2-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                    <p class="text-xs font-semibold">Data Maklumat Pelayanan Belum Diatur</p>
                </div>
                @endif
            </div>

        </div>
    </div>
</section>

<!-- Section Galeri & Album Kegiatan (2 Album + 2 Video) -->
<section id="galeri" class="py-16 bg-slate-50 border-b border-slate-200/80" x-data="{ 
    lightboxOpen: false, 
    lightboxSrc: '', 
    lightboxTitle: '', 
    lightboxSlug: '', 
    videoOpen: false, 
    videoEmbedUrl: '', 
    videoTitle: '' 
}">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 pb-3 border-b-2 border-slate-200 reveal fade-up">
            <div>
                <span class="inline-flex items-center gap-2 px-3 py-1 bg-green-50 text-green-700 text-[10px] font-bold tracking-widest uppercase rounded-full mb-2 border border-green-200/60">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    Dokumentasi Visual & Video
                </span>
                <h2 class="text-2xl font-extrabold text-slate-800 border-b-4 border-green-600 pb-2 -mb-[14px] inline-block">Galeri Album & Video Kegiatan</h2>
                <p class="text-slate-500 mt-3 text-sm font-medium">Dokumentasi resmi foto program serta video kegiatan warga Kelurahan Sidomukti.</p>
            </div>
            <div class="flex items-center gap-3 mt-4 md:mt-0">
                <a href="{{ route('galleries.index') }}" class="hidden md:flex text-xs font-bold text-green-700 hover:text-green-800 transition items-center gap-1 uppercase tracking-wide bg-green-50 px-3.5 py-2 rounded-lg hover:bg-green-100 border border-green-200/60">
                    Semua Album Foto 
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                </a>
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <!-- 1. DUA ALBUM FOTO (2 Cards) -->
            @php
                $albumsList = (isset($galleries) && $galleries->count() > 0) ? $galleries->take(2) : collect([]);
            @endphp

            @if($albumsList->count() > 0)
                @foreach($albumsList as $index => $gallery)
                @php
                    $coverUrl = method_exists($gallery, 'getCoverUrlAttribute') ? $gallery->cover_url : (Str::startsWith($gallery->cover_image ?? $gallery->image_path, ['http://', 'https://']) ? ($gallery->cover_image ?? $gallery->image_path) : Storage::url($gallery->cover_image ?? $gallery->image_path));
                    $photoCount = $gallery->photos_count ?? (isset($gallery->photos) ? $gallery->photos->count() : 1);
                    $albumSlug = $gallery->slug ?? null;
                @endphp
                <div class="bg-white rounded-2xl overflow-hidden border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col group reveal fade-up" data-delay="{{ $index * 80 }}">
                    <!-- Cover Image -->
                    <div class="relative aspect-video w-full overflow-hidden bg-slate-900">
                        <img src="{{ $coverUrl }}" alt="{{ $gallery->title }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-95 group-hover:opacity-100">
                        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition duration-300"></div>

                        <!-- Category Badge Top-Left -->
                        <div class="absolute top-3 left-3 z-10">
                            <span class="px-2.5 py-1 bg-slate-900/80 backdrop-blur-md text-emerald-400 text-[10px] font-extrabold uppercase tracking-wider rounded-lg border border-slate-700">
                                {{ ucfirst($gallery->category ?? 'Pemberdayaan') }}
                            </span>
                        </div>

                        <!-- Count Badge Bottom-Right -->
                        <div class="absolute bottom-3 right-3 z-10">
                            <span class="px-2.5 py-1 bg-emerald-600/90 backdrop-blur-md text-white text-[11px] font-extrabold rounded-lg shadow-md flex items-center gap-1 border border-white/20">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                {{ $photoCount }} Foto
                            </span>
                        </div>

                        <!-- Overlay Button -->
                        <div class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300 bg-slate-900/40 backdrop-blur-xs">
                            <button @click.prevent="lightboxSrc = '{{ addslashes($coverUrl) }}'; lightboxTitle = '{{ addslashes($gallery->title) }}'; lightboxSlug = '{{ $albumSlug }}'; lightboxOpen = true;" class="bg-white/90 hover:bg-white text-slate-900 font-bold py-2 px-4 rounded-full text-xs shadow-lg transition transform group-hover:scale-105 flex items-center gap-2">
                                <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                                Perbesar Cover
                            </button>
                        </div>
                    </div>

                    <!-- Content Info -->
                    <div class="p-4 flex flex-col justify-between flex-grow">
                        <div>
                            @if($albumSlug)
                            <a href="{{ route('galleries.show', $albumSlug) }}">
                                <h3 class="font-bold text-sm text-slate-800 leading-snug group-hover:text-green-700 transition line-clamp-2 mb-2">
                                    {{ $gallery->title }}
                                </h3>
                            </a>
                            @else
                            <h3 class="font-bold text-sm text-slate-800 leading-snug group-hover:text-green-700 transition line-clamp-2 mb-2">
                                {{ $gallery->title }}
                            </h3>
                            @endif
                            <p class="text-xs text-slate-500 font-medium">
                                {{ $gallery->event_date ? \Carbon\Carbon::parse($gallery->event_date)->translatedFormat('d F Y') : 'Dokumentasi Kelurahan' }}
                            </p>
                        </div>

                        <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                            @if($albumSlug)
                            <a href="{{ route('galleries.show', $albumSlug) }}" class="inline-flex items-center gap-1 text-xs font-bold text-green-600 hover:text-green-700 transition">
                                Lihat Album 
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                            </a>
                            @else
                            <button @click.prevent="lightboxSrc = '{{ addslashes($coverUrl) }}'; lightboxTitle = '{{ addslashes($gallery->title) }}'; lightboxOpen = true;" class="inline-flex items-center gap-1 text-xs font-bold text-green-600 hover:text-green-700 transition">
                                Perbesar 
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                            </button>
                            @endif
                        </div>
                    </div>
                </div>
                @endforeach
            @else
                <!-- Fallback 2 Dummy Album Cards if DB empty -->
                @foreach([
                    ['title' => 'Pelatihan & Pemberdayaan UMKM Kripik Warga Sidomukti', 'date' => '12 August 2026', 'cat' => 'Pemberdayaan', 'img' => 'https://images.unsplash.com/photo-1542744100-8a38a7611dc8?q=80&w=600&auto=format&fit=crop'],
                    ['title' => 'Peresmian Drainase Lingkungan & Gotong Royong RW 03', 'date' => '28 July 2026', 'cat' => 'Pembangunan', 'img' => 'https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=600&auto=format&fit=crop']
                ] as $index => $dummyAlbum)
                <div class="bg-white rounded-2xl overflow-hidden border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col group reveal fade-up" data-delay="{{ $index * 80 }}">
                    <div class="relative aspect-video w-full overflow-hidden bg-slate-900">
                        <img src="{{ $dummyAlbum['img'] }}" alt="{{ $dummyAlbum['title'] }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-95">
                        <div class="absolute top-3 left-3 z-10">
                            <span class="px-2.5 py-1 bg-slate-900/80 backdrop-blur-md text-emerald-400 text-[10px] font-extrabold uppercase tracking-wider rounded-lg border border-slate-700">{{ $dummyAlbum['cat'] }}</span>
                        </div>
                        <div class="absolute bottom-3 right-3 z-10">
                            <span class="px-2.5 py-1 bg-emerald-600/90 backdrop-blur-md text-white text-[11px] font-extrabold rounded-lg shadow-md flex items-center gap-1 border border-white/20">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                4 Foto
                            </span>
                        </div>
                    </div>
                    <div class="p-4 flex flex-col justify-between flex-grow">
                        <div>
                            <h3 class="font-bold text-sm text-slate-800 leading-snug group-hover:text-green-700 transition line-clamp-2 mb-2">{{ $dummyAlbum['title'] }}</h3>
                            <p class="text-xs text-slate-500 font-medium">{{ $dummyAlbum['date'] }}</p>
                        </div>
                        <div class="mt-4 pt-3 border-t border-slate-100">
                            <button @click.prevent="lightboxSrc = '{{ addslashes($dummyAlbum['img']) }}'; lightboxTitle = '{{ addslashes($dummyAlbum['title']) }}'; lightboxOpen = true;" class="inline-flex items-center gap-1 text-xs font-bold text-green-600 hover:text-green-700 transition">
                                Perbesar Cover <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                            </button>
                        </div>
                    </div>
                </div>
                @endforeach
            @endif

            <!-- 2. DUA VIDEO DOKUMENTASI (2 Cards) -->
            @php
                $videosList = (isset($videos) && $videos->count() > 0) ? $videos->take(2) : collect([]);
            @endphp

            @if($videosList->count() > 0)
                @foreach($videosList as $index => $video)
                @php
                    $vThumb = $video->thumbnail_url;
                    $vEmbed = $video->embed_url;
                @endphp
                <div class="bg-white rounded-2xl overflow-hidden border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col group reveal fade-up" data-delay="{{ ($index + 2) * 80 }}">
                    <!-- Thumbnail with Play Icon -->
                    <div class="relative aspect-video w-full overflow-hidden bg-slate-900 cursor-pointer" @click="videoEmbedUrl = '{{ addslashes($vEmbed) }}'; videoTitle = '{{ addslashes($video->title) }}'; videoOpen = true;">
                        <img src="{{ $vThumb }}" alt="{{ $video->title }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-90 group-hover:opacity-100">
                        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>

                        <!-- Category Badge Top-Left -->
                        <div class="absolute top-3 left-3 z-10">
                            <span class="px-2.5 py-1 bg-rose-600/90 backdrop-blur-md text-white text-[10px] font-extrabold uppercase tracking-wider rounded-lg border border-rose-400/40 shadow-sm flex items-center gap-1">
                                <svg class="w-3 h-3 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                {{ ucfirst($video->category ?? 'Video Kegiatan') }}
                            </span>
                        </div>

                        <!-- Duration Badge Bottom-Right -->
                        <div class="absolute bottom-3 right-3 z-10">
                            <span class="px-2.5 py-1 bg-slate-900/90 backdrop-blur-md text-slate-200 text-[10px] font-bold rounded-lg border border-slate-700 shadow-sm">
                                {{ $video->duration ?? 'Video Dok.' }}
                            </span>
                        </div>

                        <!-- Center Play Icon -->
                        <div class="absolute inset-0 flex items-center justify-center">
                            <div class="w-12 h-12 rounded-full bg-rose-600 text-white shadow-xl shadow-rose-600/40 flex items-center justify-center group-hover:scale-110 group-hover:bg-rose-500 transition duration-300 border-2 border-white/80">
                                <svg class="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                            </div>
                        </div>
                    </div>

                    <!-- Content Info -->
                    <div class="p-4 flex flex-col justify-between flex-grow">
                        <div>
                            <h3 @click="videoEmbedUrl = '{{ addslashes($vEmbed) }}'; videoTitle = '{{ addslashes($video->title) }}'; videoOpen = true;" class="font-bold text-sm text-slate-800 leading-snug group-hover:text-rose-600 transition line-clamp-2 mb-2 cursor-pointer">
                                {{ $video->title }}
                            </h3>
                            <p class="text-xs text-slate-500 font-medium line-clamp-1">
                                {{ $video->description ?? 'Video Liputan Resmi Kelurahan Sidomukti' }}
                            </p>
                        </div>

                        <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                            <button type="button" @click="videoEmbedUrl = '{{ addslashes($vEmbed) }}'; videoTitle = '{{ addslashes($video->title) }}'; videoOpen = true;" class="inline-flex items-center gap-1.5 text-xs font-bold text-rose-600 hover:text-rose-700 transition cursor-pointer">
                                <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                Putar Video 
                            </button>
                        </div>
                    </div>
                </div>
                @endforeach
            @else
                <!-- Fallback 2 Dummy Video Cards if DB empty -->
                @foreach([
                    ['title' => 'Video Profil & Potensi Pembangunan Kelurahan Sidomukti', 'cat' => 'Profil Desa', 'dur' => '04:15', 'embed' => 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'thumb' => 'https://images.unsplash.com/photo-1574626003295-d868953930b8?q=80&w=600&auto=format&fit=crop'],
                    ['title' => 'Liputan Khusus Pelaksanaan Musrenbangbang Kelurahan', 'cat' => 'Liputan Khusus', 'dur' => '06:30', 'embed' => 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'thumb' => 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?q=80&w=600&auto=format&fit=crop']
                ] as $index => $dummyVid)
                <div class="bg-white rounded-2xl overflow-hidden border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col group reveal fade-up" data-delay="{{ ($index + 2) * 80 }}">
                    <div class="relative aspect-video w-full overflow-hidden bg-slate-900 cursor-pointer" @click="videoEmbedUrl = '{{ addslashes($dummyVid['embed']) }}'; videoTitle = '{{ addslashes($dummyVid['title']) }}'; videoOpen = true;">
                        <img src="{{ $dummyVid['thumb'] }}" alt="{{ $dummyVid['title'] }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-90">
                        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>

                        <div class="absolute top-3 left-3 z-10">
                            <span class="px-2.5 py-1 bg-rose-600/90 backdrop-blur-md text-white text-[10px] font-extrabold uppercase tracking-wider rounded-lg border border-rose-400/40 shadow-sm flex items-center gap-1">
                                <svg class="w-3 h-3 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                {{ $dummyVid['cat'] }}
                            </span>
                        </div>

                        <div class="absolute bottom-3 right-3 z-10">
                            <span class="px-2.5 py-1 bg-slate-900/90 backdrop-blur-md text-slate-200 text-[10px] font-bold rounded-lg border border-slate-700 shadow-sm">
                                {{ $dummyVid['dur'] }}
                            </span>
                        </div>

                        <div class="absolute inset-0 flex items-center justify-center">
                            <div class="w-12 h-12 rounded-full bg-rose-600 text-white shadow-xl shadow-rose-600/40 flex items-center justify-center group-hover:scale-110 group-hover:bg-rose-500 transition duration-300 border-2 border-white/80">
                                <svg class="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                            </div>
                        </div>
                    </div>

                    <div class="p-4 flex flex-col justify-between flex-grow">
                        <div>
                            <h3 @click="videoEmbedUrl = '{{ addslashes($dummyVid['embed']) }}'; videoTitle = '{{ addslashes($dummyVid['title']) }}'; videoOpen = true;" class="font-bold text-sm text-slate-800 leading-snug group-hover:text-rose-600 transition line-clamp-2 mb-2 cursor-pointer">
                                {{ $dummyVid['title'] }}
                            </h3>
                            <p class="text-xs text-slate-500 font-medium">Dokumentasi Video Kelurahan</p>
                        </div>
                        <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                            <button type="button" @click="videoEmbedUrl = '{{ addslashes($dummyVid['embed']) }}'; videoTitle = '{{ addslashes($dummyVid['title']) }}'; videoOpen = true;" class="inline-flex items-center gap-1.5 text-xs font-bold text-rose-600 hover:text-rose-700 transition cursor-pointer">
                                <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                Putar Video 
                            </button>
                        </div>
                    </div>
                </div>
                @endforeach
            @endif
        </div>

        <div class="mt-8 text-center md:hidden">
            <a href="{{ route('galleries.index') }}" class="inline-flex text-xs font-bold text-white transition items-center gap-2 uppercase tracking-wide bg-green-600 hover:bg-green-700 px-6 py-3 rounded-xl shadow">Semua Dokumentasi <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg></a>
        </div>
    </div>

    <!-- Seksi Kemitraan Strategis & Mitra Kerja -->
    <section id="kemitraan" class="py-16 bg-white relative z-10 border-t border-slate-200/80">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 reveal fade-up">
                <span class="inline-flex items-center gap-2 px-4 py-1.5 bg-emerald-50 text-emerald-700 text-[11px] font-extrabold tracking-widest uppercase rounded-full mb-4 border border-emerald-200/60 shadow-xs">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                    Sinergi & Kolaborasi
                </span>
                <h2 class="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">Mitra Kerja & Kemitraan Strategis</h2>
                <p class="text-slate-500 mt-3 font-medium max-w-2xl mx-auto text-sm sm:text-base leading-relaxed">
                    Kelurahan Sidomukti menjalin kerjasama berkelanjutan dengan instansi pemerintah, BUMN/BUMD, lembaga pendidikan, dan sektor swasta demi kemajuan warga.
                </p>
                <div class="w-20 h-[3px] bg-emerald-600 mx-auto mt-4 rounded-full"></div>
            </div>

            @if(isset($partnerships) && $partnerships->count() > 0)
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                @foreach($partnerships as $index => $partner)
                <div class="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between group reveal fade-up" data-delay="{{ $index * 80 }}">
                    <div>
                        <!-- Logo Container -->
                        <div class="w-full h-20 bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-center justify-center mb-4 group-hover:bg-emerald-50/50 group-hover:border-emerald-200 transition duration-300">
                            <img src="{{ $partner->logo }}" alt="{{ $partner->name }}" class="max-h-full max-w-full object-contain group-hover:scale-105 transition duration-300">
                        </div>

                        <!-- Category Badge -->
                        <div class="mb-2">
                            <span class="px-2.5 py-1 bg-emerald-100/70 text-emerald-800 text-[10px] font-extrabold uppercase tracking-wider rounded-lg border border-emerald-200/60 inline-block">
                                {{ $partner->category }}
                            </span>
                        </div>

                        <!-- Partner Name & Description -->
                        <h3 class="font-bold text-sm text-slate-800 group-hover:text-emerald-700 transition leading-snug mb-2 line-clamp-2">
                            {{ $partner->name }}
                        </h3>
                        @if($partner->description)
                        <p class="text-xs text-slate-500 leading-relaxed line-clamp-3 mb-4">
                            {{ $partner->description }}
                        </p>
                        @endif
                    </div>

                    @if($partner->website)
                    <div class="pt-3 border-t border-slate-100 mt-auto">
                        <a href="{{ $partner->website }}" target="_blank" class="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 group-hover:translate-x-0.5 transition">
                            <span>Kunjungi Situs Resmi</span>
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                        </a>
                    </div>
                    @endif
                </div>
                @endforeach
            </div>
            @else
            <div class="text-center py-10 text-slate-400 text-xs">
                Belum ada data kemitraan aktif yang ditampilkan.
            </div>
            @endif
        </div>
    </section>

    <!-- 1. Lightbox Modal Foto -->
    <div x-show="lightboxOpen" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" @click="lightboxOpen = false" @keydown.escape.window="lightboxOpen = false" class="fixed inset-0 z-[100] flex items-center justify-center p-4 lightbox-overlay bg-slate-950/80 backdrop-blur-md" style="display: none;">
        <div @click.stop class="relative max-w-4xl w-full max-h-[85vh] bg-white rounded-2xl overflow-hidden shadow-2xl border border-slate-200">
            <button @click="lightboxOpen = false" class="absolute top-4 right-4 z-10 w-10 h-10 bg-slate-900/80 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-red-600 transition cursor-pointer">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
            <img :src="lightboxSrc" :alt="lightboxTitle" class="w-full max-h-[70vh] object-contain bg-slate-950">
            <div class="p-5 bg-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                    <h3 class="text-slate-900 font-bold text-base md:text-lg" x-text="lightboxTitle"></h3>
                    <p class="text-slate-500 text-xs mt-0.5">Kelurahan Sidomukti — Dokumentasi Galeri Album</p>
                </div>
                <template x-if="lightboxSlug">
                    <a :href="'/galeri/' + lightboxSlug" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold text-xs transition inline-flex items-center gap-1.5">
                        Buka Album Full
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                    </a>
                </template>
            </div>
        </div>
    </div>

    <!-- 2. Lightbox Modal Video Embed YouTube -->
    <div x-show="videoOpen" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" @click="videoOpen = false; videoEmbedUrl = ''" @keydown.escape.window="videoOpen = false; videoEmbedUrl = ''" class="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md" style="display: none;" x-cloak>
        <div @click.stop class="relative max-w-4xl w-full bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-slate-800">
            <div class="flex items-center justify-between px-5 py-3 border-b border-slate-800 text-white">
                <div class="flex items-center gap-2">
                    <span class="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
                    <h3 class="font-bold text-sm truncate max-w-lg" x-text="videoTitle"></h3>
                </div>
                <button @click="videoOpen = false; videoEmbedUrl = ''" class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            <div class="relative aspect-video w-full bg-black">
                <template x-if="videoEmbedUrl">
                    <iframe :src="videoEmbedUrl + (videoEmbedUrl.includes('?') ? '&' : '?') + 'autoplay=1'" class="w-full h-full" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </template>
            </div>
        </div>
    </div>
@endsection
