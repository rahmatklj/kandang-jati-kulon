@extends('layouts.admin')

@section('title', 'Kelola Integrasi SP4N-LAPOR! & Pengaduan Warga')

@section('content')
<div class="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
    <div>
        <h2 class="text-2xl font-bold text-slate-800">Kelola Integrasi SP4N-LAPOR! & Pengaduan Warga</h2>
        <p class="text-slate-500 text-sm">Kelola konfigurasi layanan aduan SP4N-LAPOR! serta tindak lanjut pengaduan masyarakat Kelurahan Sidomukti.</p>
    </div>
    <div>
        <a href="https://www.lapor.go.id/" target="_blank" class="inline-flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-sm transition">
            <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
            Portal Resmi SP4N-LAPOR!
        </a>
    </div>
</div>

@if(session('success'))
<div class="bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 p-4 rounded-xl mb-6 shadow-sm flex items-center justify-between" role="alert">
    <div class="flex items-center gap-3">
        <svg class="w-5 h-5 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <span class="font-medium text-sm">{{ session('success') }}</span>
    </div>
    <button onclick="this.parentElement.remove()" class="text-emerald-500 hover:text-emerald-700 font-bold">&times;</button>
</div>
@endif

<!-- Form Konfigurasi SP4N-LAPOR! -->
<div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
    <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
        <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-red-50 text-red-600 flex items-center justify-center font-bold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"></path></svg>
            </div>
            <div>
                <h3 class="font-bold text-slate-800 text-base">Pengaturan Integrasi Portal SP4N-LAPOR!</h3>
                <p class="text-slate-500 text-xs">Konfigurasi tautan dan petunjuk pengaduan resmi nasional Kemendagri / Pemkab.</p>
            </div>
        </div>
    </div>
    
    <form action="{{ route('dashboard.settings.update') }}" method="POST" class="p-6 md:p-8 space-y-6">
        @csrf
        @method('PUT')

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Tautan / Link Portal SP4N-LAPOR!</label>
                <input type="url" name="lapor_link" value="{{ $settings['lapor_link'] ?? 'https://www.lapor.go.id/' }}" required class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-mono text-slate-800" placeholder="https://www.lapor.go.id/">
            </div>
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Kode / Nama Instansi Pengaduan</label>
                <input type="text" name="lapor_instansi" value="{{ $settings['lapor_instansi'] ?? 'Pemerintah Kabupaten Probolinggo - Kelurahan Sidomukti' }}" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800" placeholder="Contoh: Pemkab Probolinggo">
            </div>
        </div>

        <div>
            <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Petunjuk & Panduan Alur Layanan Pengaduan Warga</label>
            <textarea name="lapor_guide" rows="3" class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-xs font-medium text-slate-800">{{ $settings['lapor_guide'] ?? 'Masyarakat Kelurahan Sidomukti dapat menyampaikan aspirasi, pengaduan pelayanan publik, dan laporan infrastruktur melalui kanal resmi SP4N-LAPOR! atau formulir pengaduan langsung kantor kelurahan.' }}</textarea>
        </div>

        <div class="flex justify-end pt-2">
            <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition">Simpan Konfigurasi SP4N-LAPOR!</button>
        </div>
    </form>
</div>

<!-- Daftar Pengaduan Masuk Warga -->
<div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
        <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
            </div>
            <div>
                <h3 class="font-bold text-slate-800 text-base">Arsip Pengaduan & Laporan Warga</h3>
                <p class="text-slate-500 text-xs">Daftar laporan pengaduan masyarakat yang dikirimkan via portal publik.</p>
            </div>
        </div>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-xs">
            <thead>
                <tr class="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-200">
                    <th class="p-4">Tanggal & Pelapor</th>
                    <th class="p-4">Kategori & Judul Laporan</th>
                    <th class="p-4">Lokasi Kejadian</th>
                    <th class="p-4">Status Laporan</th>
                    <th class="p-4 text-right">Tindak Lanjut / Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 font-medium">
                @forelse($complaints as $complaint)
                <tr class="hover:bg-slate-50/70 transition">
                    <td class="p-4">
                        <div class="font-bold text-slate-800">{{ $complaint->name }}</div>
                        <div class="text-[11px] text-slate-500">HP: {{ $complaint->phone }}</div>
                        <div class="text-[10px] text-slate-400 mt-0.5">{{ $complaint->created_at->format('d M Y, H:i') }}</div>
                    </td>
                    <td class="p-4">
                        <span class="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md font-bold uppercase text-[9px] mb-1 inline-block">
                            {{ $complaint->category }}
                        </span>
                        <div class="font-bold text-slate-800 text-sm line-clamp-1">{{ $complaint->title }}</div>
                        <div class="text-slate-500 line-clamp-2 mt-0.5 text-[11px]">{{ $complaint->description }}</div>
                    </td>
                    <td class="p-4 text-slate-600">
                        {{ $complaint->location }}
                    </td>
                    <td class="p-4">
                        @if($complaint->status === 'pending')
                            <span class="px-2.5 py-1 bg-amber-100 text-amber-800 rounded-full font-bold uppercase text-[10px]">Belum Dibaca</span>
                        @elseif($complaint->status === 'processing')
                            <span class="px-2.5 py-1 bg-blue-100 text-blue-800 rounded-full font-bold uppercase text-[10px]">Diproses</span>
                        @elseif($complaint->status === 'resolved')
                            <span class="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold uppercase text-[10px]">Selesai</span>
                        @else
                            <span class="px-2.5 py-1 bg-red-100 text-red-800 rounded-full font-bold uppercase text-[10px]">Ditolak</span>
                        @endif
                    </td>
                    <td class="p-4 text-right">
                        <div class="inline-flex items-center gap-2">
                            <form action="{{ route('dashboard.complaints.update-status', $complaint->id) }}" method="POST" class="inline">
                                @csrf
                                @method('PUT')
                                <select name="status" onchange="this.form.submit()" class="text-[11px] font-bold py-1 px-2 border border-slate-200 rounded-lg bg-white">
                                    <option value="pending" {{ $complaint->status === 'pending' ? 'selected' : '' }}>Pending</option>
                                    <option value="processing" {{ $complaint->status === 'processing' ? 'selected' : '' }}>Diproses</option>
                                    <option value="resolved" {{ $complaint->status === 'resolved' ? 'selected' : '' }}>Selesai</option>
                                    <option value="rejected" {{ $complaint->status === 'rejected' ? 'selected' : '' }}>Ditolak</option>
                                </select>
                            </form>

                            <form action="{{ route('dashboard.complaints.destroy', $complaint->id) }}" method="POST" onsubmit="return confirm('Hapus pengaduan ini?')" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="p-1.5 text-slate-400 hover:text-red-600 transition" title="Hapus Laporan">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5" class="p-8 text-center text-slate-400 font-medium">
                        Belum ada laporan pengaduan warga yang masuk.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($complaints->hasPages())
    <div class="p-4 border-t border-slate-200">
        {{ $complaints->links() }}
    </div>
    @endif
</div>
@endsection
