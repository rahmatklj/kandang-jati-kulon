@extends('layouts.admin')

@section('title', 'Kelola Wilayah RT & RW')

@section('content')
<div class="mb-6">
    <h2 class="text-2xl font-bold text-slate-800">Kelola Wilayah RT & RW</h2>
    <p class="text-slate-500 text-sm">Kelola data Sebaran Lingkungan Rukun Warga (RW) dan Rukun Tetangga (RT) Kelurahan Sidomukti.</p>
</div>

@if(session('success'))
<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
    <span class="block sm:inline">{{ session('success') }}</span>
</div>
@endif

@if($errors->any())
<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
    <ul class="list-disc list-inside">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif

<!-- Sebaran Lingkungan Rukun Warga (RW) -->
<div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="p-6 border-b border-slate-100 flex items-center justify-between">
        <div class="flex items-center gap-2">
            <div class="w-3 h-3 rounded-full bg-green-500"></div>
            <h3 class="text-lg font-bold text-slate-800">Sebaran Lingkungan Rukun Warga (RW)</h3>
        </div>
        <button type="button" onclick="openModal('addModal')" class="bg-green-50 text-green-700 font-bold py-2 px-4 rounded-lg text-sm hover:bg-green-100 transition">
            + Tambah RW
        </button>
    </div>
    
    <div class="p-6">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                        <th scope="col" class="px-6 py-4">Nama Lingkungan / RW</th>
                        <th scope="col" class="px-6 py-4">Jumlah RT</th>
                        <th scope="col" class="px-6 py-4">Estimasi Penduduk</th>
                        <th scope="col" class="px-6 py-4 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse($rukunWargas as $rw)
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4 font-bold text-slate-800">{{ $rw->nama_rw }}</td>
                        <td class="px-6 py-4 font-bold text-green-600">{{ $rw->jumlah_rt }} RT</td>
                        <td class="px-6 py-4"><span class="font-bold text-slate-800">{{ $rw->estimasi_penduduk }}</span> Jiwa</td>
                        <td class="px-6 py-4 text-right">
                            <button onclick="openEditModal({{ $rw->id }}, '{{ addslashes($rw->nama_rw) }}', {{ $rw->jumlah_rt }}, {{ $rw->estimasi_penduduk }})" class="text-slate-600 hover:text-slate-900 bg-slate-100 px-3 py-1.5 rounded-md text-xs font-semibold mr-2 transition">Edit</button>
                            <form action="{{ route('dashboard.rt-rw.destroy', $rw->id) }}" method="POST" class="inline-block" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data RW ini?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:text-red-800 bg-red-50 px-3 py-1.5 rounded-md text-xs font-semibold transition">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="px-6 py-8 text-center text-slate-500 italic">Belum ada data sebaran Rukun Warga.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah RW -->
<div id="addModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 overflow-hidden transform scale-95 transition-transform duration-300">
        <div class="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
            <h3 class="font-bold text-lg text-slate-800">Tambah Rukun Warga</h3>
            <button onclick="closeModal('addModal')" class="text-slate-400 hover:text-slate-600">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form action="{{ route('dashboard.rt-rw.store') }}" method="POST" class="p-6">
            @csrf
            <div class="space-y-4 mb-6">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Nama Lingkungan / RW</label>
                    <input type="text" name="nama_rw" class="w-full px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500" placeholder="Contoh: RW 01 Kraksaan Timur" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Jumlah RT</label>
                    <input type="number" name="jumlah_rt" class="w-full px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Estimasi Penduduk (Jiwa)</label>
                    <input type="number" name="estimasi_penduduk" class="w-full px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500" required>
                </div>
            </div>
            <div class="flex justify-end gap-2">
                <button type="button" onclick="closeModal('addModal')" class="px-4 py-2 text-sm font-bold text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200">Batal</button>
                <button type="submit" class="px-4 py-2 text-sm font-bold text-white bg-green-600 rounded-lg hover:bg-green-700">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Edit RW -->
<div id="editModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 overflow-hidden transform scale-95 transition-transform duration-300">
        <div class="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
            <h3 class="font-bold text-lg text-slate-800">Edit Rukun Warga</h3>
            <button onclick="closeModal('editModal')" class="text-slate-400 hover:text-slate-600">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form id="editForm" method="POST" class="p-6">
            @csrf
            @method('PUT')
            <div class="space-y-4 mb-6">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Nama Lingkungan / RW</label>
                    <input type="text" name="nama_rw" id="edit_nama_rw" class="w-full px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Jumlah RT</label>
                    <input type="number" name="jumlah_rt" id="edit_jumlah_rt" class="w-full px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Estimasi Penduduk (Jiwa)</label>
                    <input type="number" name="estimasi_penduduk" id="edit_estimasi_penduduk" class="w-full px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500" required>
                </div>
            </div>
            <div class="flex justify-end gap-2">
                <button type="button" onclick="closeModal('editModal')" class="px-4 py-2 text-sm font-bold text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200">Batal</button>
                <button type="submit" class="px-4 py-2 text-sm font-bold text-white bg-green-600 rounded-lg hover:bg-green-700">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openModal(id) {
        const modal = document.getElementById(id);
        const inner = modal.querySelector('div');
        modal.classList.remove('hidden');
        setTimeout(() => {
            modal.classList.remove('opacity-0');
            inner.classList.remove('scale-95');
        }, 10);
    }

    function closeModal(id) {
        const modal = document.getElementById(id);
        const inner = modal.querySelector('div');
        modal.classList.add('opacity-0');
        inner.classList.add('scale-95');
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 300);
    }

    function openEditModal(id, nama, rt, penduduk) {
        document.getElementById('edit_nama_rw').value = nama;
        document.getElementById('edit_jumlah_rt').value = rt;
        document.getElementById('edit_estimasi_penduduk').value = penduduk;
        
        // Update form action
        const form = document.getElementById('editForm');
        form.action = `/dashboard/rt-rw/${id}`;
        
        openModal('editModal');
    }
</script>
@endsection
