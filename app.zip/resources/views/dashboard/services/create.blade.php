@extends('layouts.admin')

@section('title', 'Tambah Dokumen SOP / Standar Pelayanan')

@section('content')
<div class="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
    <div>
        <div class="flex items-center gap-2 text-sm text-slate-500 mb-1">
            <a href="{{ route('dashboard.services.index') }}" class="hover:text-emerald-600 transition">Standar Pelayanan & SOP</a>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
            <span class="text-slate-700 font-medium">Tambah Dokumen</span>
        </div>
        <h2 class="text-2xl font-bold text-slate-800">Tambah Dokumen SOP / Layanan</h2>
        <p class="text-slate-500 text-sm">Tambahkan repositori dokumen SOP atau Standar Pelayanan publik baru.</p>
    </div>
    <a href="{{ route('dashboard.services.index') }}" class="inline-flex items-center gap-2 text-slate-600 hover:text-slate-800 font-medium py-2 px-4 border border-slate-200 rounded-xl shadow-sm bg-white hover:bg-slate-50 transition">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
        Kembali
    </a>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden max-w-3xl">
    <div class="p-6 border-b border-slate-100 bg-slate-50/50">
        <h3 class="font-semibold text-slate-800">Formulir Dokumen SOP</h3>
        <p class="text-xs text-slate-500">Unggah berkas PDF dan isi detail informasi layanan.</p>
    </div>

    <form action="{{ route('dashboard.services.store') }}" method="POST" enctype="multipart/form-data" class="p-6 md:p-8 space-y-6">
        @csrf

        <div>
            <label for="title" class="block text-sm font-semibold text-slate-700 mb-2">Judul Dokumen / Layanan <span class="text-red-500">*</span></label>
            <input type="text" name="title" id="title" value="{{ old('title') }}" required class="w-full px-4 py-2.5 rounded-xl border @error('title') border-red-500 ring-1 ring-red-500 @else border-slate-200 @enderror focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-sm text-sm" placeholder="Contoh: SOP Pelayanan Surat Keterangan Usaha (SKU)">
            @error('title')
                <p class="text-red-500 text-xs mt-1.5 font-medium">{{ $message }}</p>
            @enderror
        </div>

        <div>
            <label for="order" class="block text-sm font-semibold text-slate-700 mb-2">Nomor Urut Tampilan</label>
            <input type="number" name="order" id="order" value="{{ old('order') }}" min="1" class="w-36 px-4 py-2.5 rounded-xl border @error('order') border-red-500 @else border-slate-200 @enderror focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-sm text-sm" placeholder="1, 2, 3...">
            <p class="text-xs text-slate-500 mt-1.5">Urutan tampilan pada menu navbar dan halaman daftar layanan.</p>
            @error('order')
                <p class="text-red-500 text-xs mt-1.5 font-medium">{{ $message }}</p>
            @enderror
        </div>

        <div>
            <label for="description" class="block text-sm font-semibold text-slate-700 mb-2">Deskripsi / Ringkasan Layanan</label>
            <textarea name="description" id="description" rows="3" class="w-full px-4 py-2.5 rounded-xl border @error('description') border-red-500 @else border-slate-200 @enderror focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-sm text-sm" placeholder="Tuliskan ringkasan prosedur atau petunjuk singkat...">{{ old('description') }}</textarea>
            @error('description')
                <p class="text-red-500 text-xs mt-1.5 font-medium">{{ $message }}</p>
            @enderror
        </div>

        <div>
            <label for="requirements" class="block text-sm font-semibold text-slate-700 mb-2">Persyaratan Dokumen</label>
            <textarea name="requirements" id="requirements" rows="3" class="w-full px-4 py-2.5 rounded-xl border @error('requirements') border-red-500 @else border-slate-200 @enderror focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition shadow-sm text-sm" placeholder="Contoh: Foto KTP Warga, Kartu Keluarga (KK), Foto Tempat Usaha/Rumah, Surat Pengantar RT/RW (pisahkan dengan koma atau baris baru)">{{ old('requirements') }}</textarea>
            <p class="text-xs text-slate-500 mt-1.5">Pisahkan tiap poin persyaratan dengan koma (,) atau baris baru.</p>
            @error('requirements')
                <p class="text-red-500 text-xs mt-1.5 font-medium">{{ $message }}</p>
            @enderror
        </div>

        <div>
            <label class="block text-sm font-semibold text-slate-700 mb-2">Berkas Dokumen PDF (Maks. 10MB)</label>
            <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-200 border-dashed rounded-xl hover:border-emerald-400 transition bg-slate-50/50">
                <div class="space-y-2 text-center">
                    <svg class="mx-auto h-12 w-12 text-slate-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                        <path d="M28 8H12a4 4 0 00-4 4v24a4 4 0 004 4h24a4 4 0 004-4V20l-12-12z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M28 8v12h12M16 26h16M16 32h10" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <div class="flex text-sm text-slate-600 justify-center">
                        <label for="pdf_file" class="relative cursor-pointer bg-white rounded-md font-medium text-emerald-600 hover:text-emerald-500 focus-within:outline-none">
                            <span>Pilih Berkas PDF</span>
                            <input id="pdf_file" name="pdf_file" type="file" accept="application/pdf" class="sr-only">
                        </label>
                    </div>
                    <p class="text-xs text-slate-400">PDF hingga ukuran 10MB</p>
                </div>
            </div>
            @error('pdf_file')
                <p class="text-red-500 text-xs mt-1.5 font-medium">{{ $message }}</p>
            @enderror
        </div>

        <div class="pt-4 border-t border-slate-100 flex items-center">
            <input type="checkbox" name="is_active" id="is_active" value="1" {{ old('is_active', true) ? 'checked' : '' }} class="w-4 h-4 text-emerald-600 bg-slate-100 border-slate-300 rounded focus:ring-emerald-500 focus:ring-2">
            <label for="is_active" class="ml-3 text-sm font-medium text-slate-700">Tampilkan dokumen ini di menu dan halaman publik (Aktif)</label>
        </div>

        <div class="mt-8 pt-6 border-t border-slate-200 flex items-center justify-end gap-3">
            <a href="{{ route('dashboard.services.index') }}" class="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-medium text-sm transition">Batal</a>
            <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-2.5 px-6 rounded-xl shadow-sm transition flex items-center gap-2 text-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                Simpan Dokumen
            </button>
        </div>
    </form>
</div>
@endsection
