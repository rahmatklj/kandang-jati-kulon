@extends('layouts.admin')

@section('title', 'Kelola Data & Statistik')

@section('content')
<div class="mb-6">
    <h2 class="text-2xl font-bold text-slate-800">Kelola Data & Statistik Kelurahan</h2>
    <p class="text-slate-500 text-sm">Manajemen data demografi, monografi, angka statistik kependudukan, serta sebaran wilayah RT & RW.</p>
</div>

@if(session('success'))
<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
    <span class="block sm:inline">{{ session('success') }}</span>
</div>
@endif

@if($errors->any())
<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
    <ul class="list-disc list-inside">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif

<form action="{{ route('dashboard.settings.update') }}" method="POST">
    @csrf
    @method('PUT')

    <!-- 1. Angka Demografi Terkini -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
        <div class="p-6 border-b border-slate-100 flex items-center gap-2">
            <div class="w-3 h-3 rounded-full bg-green-500"></div>
            <h3 class="text-lg font-bold text-slate-800">1. Angka Demografi Terkini</h3>
        </div>
        
        <div class="p-6 md:p-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Total Penduduk (Jiwa) *</label>
                    <input type="number" name="demografi_total" value="{{ $settings['demografi_total'] ?? '2776' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Total KK *</label>
                    <input type="number" name="demografi_kk" value="{{ $settings['demografi_kk'] ?? '850' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Laki-Laki</label>
                    <input type="number" name="demografi_laki" value="{{ $settings['demografi_laki'] ?? '1402' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Perempuan</label>
                    <input type="number" name="demografi_perempuan" value="{{ $settings['demografi_perempuan'] ?? '1374' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>

                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Jumlah RW</label>
                    <input type="number" name="demografi_jumlah_rw" value="{{ $settings['demografi_jumlah_rw'] ?? '6' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Jumlah RT</label>
                    <input type="number" name="demografi_jumlah_rt" value="{{ $settings['demografi_jumlah_rt'] ?? '17' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Luas Wilayah (km²)</label>
                    <input type="text" name="demografi_luas" value="{{ $settings['demografi_luas'] ?? '3,36' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Kepadatan Penduduk</label>
                    <input type="text" name="demografi_kepadatan" value="{{ $settings['demografi_kepadatan'] ?? '826' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm" placeholder="Contoh: 826 jiwa/km²">
                </div>
            </div>
        </div>
    </div>

    <!-- 2. Data Penerima Bantuan Sosial -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
        <div class="p-6 border-b border-slate-100 flex items-center gap-2">
            <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
            <h3 class="text-lg font-bold text-slate-800">2. Data Penerima Bantuan Sosial</h3>
        </div>
        
        <div class="p-6 md:p-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Penerima PKH (Jiwa / KPM)</label>
                    <input type="number" name="demografi_pkh" value="{{ $settings['demografi_pkh'] ?? '285' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Penerima BPNT / Sembako (Jiwa / KPM)</label>
                    <input type="number" name="demografi_bpnt" value="{{ $settings['demografi_bpnt'] ?? '335' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Penerima KIS / PBI BPJS (Jiwa / KPM)</label>
                    <input type="number" name="demografi_kis" value="{{ $settings['demografi_kis'] ?? '1420' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
            </div>
        </div>
    </div>

    <!-- 3. Distribusi Mata Pencaharian Penduduk -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
        <div class="p-6 border-b border-slate-100 flex items-center gap-2">
            <div class="w-3 h-3 rounded-full bg-blue-500"></div>
            <h3 class="text-lg font-bold text-slate-800">3. Distribusi Mata Pencaharian Penduduk</h3>
        </div>
        
        <div class="p-6 md:p-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Petani & Buruh Tani (Jiwa)</label>
                    <input type="number" name="demografi_pekerjaan_petani" value="{{ $settings['demografi_pekerjaan_petani'] ?? '1240' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Pedagang & UMKM (Jiwa)</label>
                    <input type="number" name="demografi_pekerjaan_pedagang" value="{{ $settings['demografi_pekerjaan_pedagang'] ?? '850' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">Swasta & Wiraswasta (Jiwa)</label>
                    <input type="number" name="demografi_pekerjaan_swasta" value="{{ $settings['demografi_pekerjaan_swasta'] ?? '1420' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-2">PNS / TNI / Polri (Jiwa)</label>
                    <input type="number" name="demografi_pekerjaan_pns" value="{{ $settings['demografi_pekerjaan_pns'] ?? '310' }}" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition shadow-sm">
                </div>
            </div>
        </div>
    </div>

    <div class="flex justify-end mb-8">
        <button type="submit" class="bg-[#008A5E] hover:bg-green-700 text-white font-bold py-3 px-8 rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            Simpan Perubahan Statistik
        </button>
    </div>
</form>

<!-- 4. Sebaran Lingkungan Rukun Warga (RW) & RT -->
<div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
    <div class="p-6 border-b border-slate-100 flex items-center justify-between">
        <div class="flex items-center gap-2">
            <div class="w-3 h-3 rounded-full bg-teal-500"></div>
            <h3 class="text-lg font-bold text-slate-800">4. Sebaran Lingkungan Rukun Warga (RW) & RT</h3>
        </div>
        <button type="button" onclick="openModal('addModal')" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-5 rounded-xl shadow-md transition flex items-center gap-2 text-xs uppercase tracking-wider cursor-pointer">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
            Tambah RW Baru
        </button>
    </div>
    
    <div class="p-6">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                        <th scope="col" class="px-6 py-4">Nama Lingkungan / RW</th>
                        <th scope="col" class="px-6 py-4">Jumlah RT</th>
                        <th scope="col" class="px-6 py-4">Estimasi Penduduk</th>
                        <th scope="col" class="px-6 py-4 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse($rukunWargas as $rw)
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4 font-bold text-slate-800">{{ $rw->nama_rw }}</td>
                        <td class="px-6 py-4 font-bold text-emerald-600">{{ $rw->jumlah_rt }} RT</td>
                        <td class="px-6 py-4"><span class="font-bold text-slate-800">{{ number_format($rw->estimasi_penduduk, 0, ',', '.') }}</span> Jiwa</td>
                        <td class="px-6 py-4 text-right">
                            <button type="button" onclick="openEditModal({{ $rw->id }}, '{{ addslashes($rw->nama_rw) }}', {{ $rw->jumlah_rt }}, {{ $rw->estimasi_penduduk }})" class="text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold mr-2 transition cursor-pointer">Edit</button>
                            <form action="{{ route('dashboard.rt-rw.destroy', $rw->id) }}" method="POST" class="inline-block" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data RW ini?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="px-6 py-8 text-center text-slate-500 italic">Belum ada data sebaran Rukun Warga.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah RW -->
<div id="addModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden transform scale-95 transition-transform duration-300 border border-slate-100">
        <div class="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h3 class="font-bold text-lg text-slate-800">Tambah Rukun Warga (RW)</h3>
            <button onclick="closeModal('addModal')" class="text-slate-400 hover:text-slate-600 p-1">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form action="{{ route('dashboard.rt-rw.store') }}" method="POST" class="p-6">
            @csrf
            <div class="space-y-4 mb-6">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1.5">Nama Lingkungan / RW <span class="text-red-500">*</span></label>
                    <input type="text" name="nama_rw" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm shadow-xs transition" placeholder="Contoh: RW 01 Kraksaan Timur" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1.5">Jumlah RT <span class="text-red-500">*</span></label>
                    <input type="number" name="jumlah_rt" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm shadow-xs transition" placeholder="Contoh: 4" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1.5">Estimasi Penduduk (Jiwa) <span class="text-red-500">*</span></label>
                    <input type="number" name="estimasi_penduduk" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm shadow-xs transition" placeholder="Contoh: 450" required>
                </div>
            </div>
            <div class="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button type="button" onclick="closeModal('addModal')" class="px-4 py-2.5 text-sm font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 transition">Batal</button>
                <button type="submit" class="px-5 py-2.5 text-sm font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 shadow-md shadow-emerald-600/20 transition">Simpan RW</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Edit RW -->
<div id="editModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden transform scale-95 transition-transform duration-300 border border-slate-100">
        <div class="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h3 class="font-bold text-lg text-slate-800">Edit Rukun Warga (RW)</h3>
            <button onclick="closeModal('editModal')" class="text-slate-400 hover:text-slate-600 p-1">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form id="editForm" method="POST" class="p-6">
            @csrf
            @method('PUT')
            <div class="space-y-4 mb-6">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1.5">Nama Lingkungan / RW <span class="text-red-500">*</span></label>
                    <input type="text" name="nama_rw" id="edit_nama_rw" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm shadow-xs transition" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1.5">Jumlah RT <span class="text-red-500">*</span></label>
                    <input type="number" name="jumlah_rt" id="edit_jumlah_rt" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm shadow-xs transition" required>
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1.5">Estimasi Penduduk (Jiwa) <span class="text-red-500">*</span></label>
                    <input type="number" name="estimasi_penduduk" id="edit_estimasi_penduduk" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm shadow-xs transition" required>
                </div>
            </div>
            <div class="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button type="button" onclick="closeModal('editModal')" class="px-4 py-2.5 text-sm font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 transition">Batal</button>
                <button type="submit" class="px-5 py-2.5 text-sm font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 shadow-md shadow-emerald-600/20 transition">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openModal(id) {
        const modal = document.getElementById(id);
        const inner = modal.querySelector('div');
        modal.classList.remove('hidden');
        setTimeout(() => {
            modal.classList.remove('opacity-0');
            inner.classList.remove('scale-95');
        }, 10);
    }

    function closeModal(id) {
        const modal = document.getElementById(id);
        const inner = modal.querySelector('div');
        modal.classList.add('opacity-0');
        inner.classList.add('scale-95');
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 300);
    }

    function openEditModal(id, nama, rt, penduduk) {
        document.getElementById('edit_nama_rw').value = nama;
        document.getElementById('edit_jumlah_rt').value = rt;
        document.getElementById('edit_estimasi_penduduk').value = penduduk;
        
        const form = document.getElementById('editForm');
        form.action = `/dashboard/rt-rw/${id}`;
        
        openModal('editModal');
    }
</script>
@endsection
